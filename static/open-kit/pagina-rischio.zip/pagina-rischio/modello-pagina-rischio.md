---
title: "Rischio …: cosa fare"
description: "…"
---

## Perché è rilevante sul nostro territorio

…

## Cosa fare PRIMA

- …

## Cosa fare DURANTE

- …

## Cosa fare DOPO

- …

{{< cosa-non-fare titolo="Cosa NON fare" >}}
- …
{{< /cosa-non-fare >}}

{{< chi-chiamare >}}
