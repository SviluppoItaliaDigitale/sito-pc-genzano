---
title: "Kit Didattico — Scuola Secondaria di Secondo Grado"
description: "Materiale PC per studenti 14-19 anni: approfondimenti scientifici, quadro normativo, comunicazione del rischio e volontariato di protezione civile."
layout: "single"
toc: true
risorse_tema: "kit-emergenza"
---

Questo kit è rivolto ai docenti della **scuola secondaria di secondo grado** che intendono affrontare i temi della protezione civile in modo approfondito, integrando aspetti scientifici, normativi e di cittadinanza attiva.

I contenuti sono stati sviluppati dal Gruppo Comunale Volontari di Protezione Civile di Genzano di Roma e si prestano all'uso nelle ore di scienze della Terra, geografia, educazione civica, diritto e nei percorsi di formazione scuola-lavoro (fino al 2024/25 chiamati PCTO).

> 📦 **Scarica il pacchetto offline** — [`kit-scuola-secondaria-secondo-grado.zip`](/formazione/pacchetti/kit-scuola-secondaria-secondo-grado.zip) (~385 KB) contiene tutte le schede stampabili linkate da questo kit, indice cliccabile, istruzioni per l'uso. Aggiornato automaticamente quando aggiungiamo, modifichiamo o togliamo schede dal kit.

---

## Guida per il docente

### Riferimenti normativi e curricolari

Il percorso è costruito sul quadro normativo dell'**educazione civica** (Legge 20 agosto 2019 n. 92, art. 1, 3 e 6), delle **Linee guida per l'insegnamento dell'educazione civica** (D.M. 7 settembre 2024 n. 183, **applicabili a decorrere dall'anno scolastico 2024/2025**), della **Legge 17 febbraio 2025, n. 21** (conoscenze di base in materia di sicurezza nei luoghi di lavoro nell'Educazione Civica — art. 3 lett. h-ter L. 92/2019), del **D.Lgs. 13 aprile 2017 n. 62** (valutazione e certificazione competenze), del **D.Lgs. 15 aprile 2005 n. 77** (PCTO — Percorsi per le Competenze Trasversali e l'Orientamento).

Il riferimento normativo che lega la scuola al Sistema nazionale di Protezione Civile è l'**articolo 3, lettera h) della Legge 92/2019**, che include esplicitamente la *"formazione di base in materia di protezione civile"* tra i temi dell'Educazione Civica. Il **D.Lgs. 1/2018** (Codice della Protezione Civile) costituisce la cornice generale che descrive attività, organizzazione, pianificazione e ruolo del Servizio nazionale.

È coerente con:
- **Regolamento dei licei** (D.P.R. 89/2010) con le Indicazioni nazionali per i licei (D.M. 211/2010), e **Linee guida per gli istituti tecnici e professionali** (2010/2018). Dal 1° ottobre 2026 gli istituti tecnici si chiamano «licei tecnologici» e i professionali «licei professionali» ([D.L. 170/2026](https://www.gazzettaufficiale.it/atto/serie_generale/caricaDettaglioAtto/originario?atto.dataPubblicazioneGazzetta=2026-09-30&atto.codiceRedazionale=26G00190), art. 9, in attesa di conversione in legge)
- **Raccomandazione UE 2018/C 189/01** sulle 8 competenze chiave per l'apprendimento permanente
- **Obiettivi Agenda 2030** n. 8 (lavoro dignitoso), 11 (città sostenibili), 13 (lotta al cambiamento climatico) e 15 (vita sulla terra)
- **D.Lgs. 9 aprile 2008, n. 81** — Testo Unico sulla salute e sicurezza nei luoghi di lavoro, riferimento sostanziale per il modulo introdotto dalla L. 21/2025

> 📚 **Per i docenti — risorse coordinate**
>
> - **Pagina hub** [La Protezione Civile per l'Educazione Civica](/formazione/educazione-civica/) — mappatura completa dei nostri contenuti sui **3 Nuclei Concettuali del D.M. 183/2024** (Costituzione, Sostenibilità, Cittadinanza Digitale) + **Goal Agenda 2030 ONU** + tabella interdisciplinare + calendario delle 33 ore.
> - **Rubrica valutativa** pronta per la fascia: [Rubrica Ed. Civica — Secondaria di secondo grado](/formazione/schede-stampabili/rubrica-valutativa-secondaria2/) — indicatori × livelli, con esempi di giudizio descrittivo / motivazione del voto.


### Obiettivi di apprendimento formalizzati

**Conoscenze**
- Conosce il quadro normativo della protezione civile italiana e la sua evoluzione storica
- Conosce le basi scientifiche dei principali rischi naturali (sismologia, idrologia, vulcanologia, meteorologia)
- Conosce la relazione tra cambiamenti climatici ed eventi estremi
- Conosce il sistema di monitoraggio e allertamento nazionale e regionale
- Conosce il principio di sussidiarietà (art. 118 Cost.) e il ruolo del volontariato organizzato
- Conosce le **figure del D.Lgs. 81/2008** (datore di lavoro, RSPP, RLS, medico competente, preposto, lavoratore) e i **principi generali di prevenzione** (Modulo 7, L. 21/2025)
- Conosce le 5 categorie di **segnaletica ISO 7010** (divieto, avvertimento, obbligo, salvataggio, antincendio) e i criteri di scelta dei DPI

**Abilità**
- Consulta autonomamente portali scientifici e istituzionali (INGV, ISPRA, DPC, Copernicus EMS)
- Legge e interpreta dati scientifici complessi (sismogrammi, carte di pericolosità, scenari climatici)
- Produce analisi critiche della comunicazione del rischio su media tradizionali e social
- Progetta e realizza una campagna di comunicazione del rischio per un target specifico
- Valuta criticamente la qualità delle fonti informative
- Conduce un **audit di sicurezza** semplificato sull'aula/laboratorio della propria scuola (verifica cartelli, vie di fuga, estintori, DPI) e sa redigere una **Procedura Operativa Standard** sintetica

**Competenze chiave europee**
- **Competenza alfabetica funzionale avanzata**: analizza testi tecnici, giuridici, scientifici e ne produce di propri
- **Competenza matematica e scientifica**: utilizza metodologie di analisi quantitativa applicate al rischio
- **Competenza digitale avanzata**: distingue fonti, contrasta disinformazione, usa strumenti di visualizzazione dati
- **Competenza personale, sociale, imparare a imparare**: gestisce complessità, prende decisioni sotto incertezza
- **Competenza in materia di cittadinanza**: agisce da cittadino consapevole, partecipa a iniziative collettive
- **Competenza imprenditoriale**: progetta, pianifica, esegue un compito complesso in autonomia
- **Competenza in materia di consapevolezza ed espressione culturale**: riconosce la dimensione storica, culturale ed etica del rischio

### Collegamento con le discipline

| Disciplina | Argomenti collegati |
|---|---|
| **Scienze della Terra / Scienze Naturali** | Sismologia, vulcanologia, meteorologia, idrologia, geomorfologia, cambiamenti climatici |
| **Geografia** | Dissesto idrogeologico, pianificazione territoriale, antropizzazione |
| **Ed. civica / Diritto** | D.Lgs. 1/2018, sussidiarietà (art. 5 e 118 Cost.), volontariato, diritti in emergenza |
| **Fisica** | Onde sismiche, propagazione dell'energia, strumenti di misura, statistica applicata |
| **Italiano** | Analisi della comunicazione istituzionale, retorica del rischio, testo argomentativo |
| **Storia** | Eventi catastrofici e risposta istituzionale (Messina 1908, Vajont 1963, Irpinia 1980, Amatrice 2016) |
| **Filosofia** | Etica della responsabilità (Jonas), principio di precauzione, rischio e scelta pubblica |
| **Informatica / Tecnologia** | Big data, GIS, Cell Broadcast (IT-alert), machine learning applicato al rischio |
| **Arte e immagine** | Infografica, data visualization, poster campagne istituzionali |
| **Lingue straniere** | Analisi di documenti UE, OMS, IPCC in lingua originale; confronto con sistemi di altri Paesi |
| **PCTO** | Percorsi di volontariato con organizzazioni di protezione civile |

### Durata consigliata e tabella del percorso

Il percorso completo si articola in **Moduli da 60-90 minuti**. Ogni modulo è autonomo e può essere approfondito ulteriormente per i percorsi PCTO.

| Modulo | Tema | Durata | Classi consigliate |
|---|---|---|---|
| 1 | Quadro normativo | 60' | III-V |
| 2 | Basi scientifiche del rischio sismico | 90' | III-V |
| 3 | Rischio idrogeologico e cambiamenti climatici | 90' | III-V |
| 4 | Sistema di monitoraggio e allertamento | 90' | III-V |
| 5 | Comunicazione del rischio | 60-90' | III-V |
| 6 | Volontariato e cittadinanza attiva | 60-90' | III-V |
| 7 | [Sicurezza nei luoghi di lavoro (L. 21/2025)](#modulo-sicurezza-lavoro) | 4-6 ore | III-V |

**Compito di realtà / progetto di classe**: +6-12 ore (vedi sezione dedicata)
**Percorso PCTO strutturato**: 30-50 ore (vedi sezione dedicata)

**Totale complessivo**: 12-18 ore per il percorso curricolare base, fino a 75+ ore integrando PCTO e Progetto.

### Prerequisiti

- Competenze di studio autonomo (lettura testo tecnico, sintesi, ricerca fonti)
- Conoscenze di base di fisica (onde, forza, energia) e scienze (geologia, meteorologia)
- Uso autonomo di strumenti informatici e di ricerca online
- Capacità di lavorare in gruppo su progetti di medio-lungo periodo

### Metodologie didattiche suggerite

- **Flipped classroom**: materiali di studio consegnati prima della lezione, discussione e analisi critica in aula
- **Caso studio**: analisi approfondita di un evento reale (es. Amatrice 2016 + processo Commissione Grandi Rischi; Ischia 2017 frane; Genova 2018 crollo ponte Morandi)
- **Debate**: dibattito strutturato su temi controversi (art. 118 Cost., responsabilità Stato/cittadino, principio di precauzione)
- **Project-based learning**: progetto di classe semestrale (vedi sezione dedicata)
- **Service learning**: il gruppo classe realizza un servizio concreto per la comunità (es. campagna informativa per un quartiere)
- **EAS (Episodi di Apprendimento Situato)**: micro-attività di 30 minuti che mettono lo studente davanti a un problema reale
- **Cooperative learning**: gruppi eterogenei per le attività di ricerca e produzione

---

## Modulo 1 — Il quadro normativo

### Evoluzione storica

Il sistema italiano di protezione civile nasce dalla risposta alle grandi catastrofi:

| Anno | Evento | Conseguenza normativa |
|---|---|---|
| 1908 | Terremoto di Messina | Prime norme sul soccorso |
| 1966 | Alluvione di Firenze | Consapevolezza della necessità di coordinamento |
| 1970 | L. 996/1970 | Prima legge organica sulla protezione civile |
| 1980 | Terremoto dell'Irpinia | Emerge la forza del volontariato organizzato |
| 1992 | L. 225/1992 (Legge Zamberletti) | Nasce il Servizio Nazionale di Protezione Civile |
| 2018 | D.Lgs. 1/2018 | Codice della Protezione Civile — riforma organica del sistema |

### Il Codice della Protezione Civile (D.Lgs. 1/2018)

Il Codice definisce:

**Le componenti del Servizio Nazionale:**
- Amministrazioni dello Stato (centrali e periferiche)
- Regioni, Province, Comuni e Città metropolitane
- Comunità scientifica
- Volontariato organizzato
- Corpo Nazionale dei Vigili del Fuoco
- Forze Armate e Forze di Polizia
- Croce Rossa Italiana e Corpo Nazionale Soccorso Alpino

**Le tipologie di eventi emergenziali:**
- **Tipo a**: emergenze locali gestibili dal singolo comune
- **Tipo b**: emergenze che richiedono il coordinamento di più enti (provinciale/regionale)
- **Tipo c**: emergenze di rilievo nazionale che richiedono la dichiarazione dello stato di emergenza

**Il principio di sussidiarietà:**
La risposta parte dal livello più vicino al cittadino (il Comune) e si amplia progressivamente in base alla gravità dell'evento.

### Il ruolo del Sindaco

Il Sindaco è **autorità comunale di protezione civile** (art. 12 del Codice). In particolare:
- Adotta il Piano di Protezione Civile comunale
- Attiva il Centro Operativo Comunale (COC) in emergenza
- Dispone l'evacuazione e le prime misure di soccorso
- Informa la popolazione
- Può emettere ordinanze contingibili e urgenti

### Attività: analisi del Codice

Dividete la classe in gruppi e assegnate a ciascuno una sezione del D.Lgs. 1/2018 (consultabile su [Normattiva](https://www.normattiva.it/)). Ogni gruppo presenta alla classe:
- I principi fondamentali della sezione assegnata
- Le responsabilità dei soggetti coinvolti
- Un esempio pratico di applicazione

---

## Modulo 2 — Basi scientifiche del rischio sismico

### Tettonica delle placche

L'Italia si trova al margine di convergenza tra la **placca africana** e la **placca euroasiatica**. Questa collisione genera:
- Compressione e sollevamento (Appennini, Alpi)
- Faglie attive che accumulano energia elastica
- Rilascio improvviso di energia sotto forma di onde sismiche (terremoti)

### Onde sismiche

| Tipo | Caratteristiche | Velocità |
|---|---|---|
| **Onde P** (primarie) | Compressione, si propagano in tutti i materiali | 5-8 km/s nella crosta |
| **Onde S** (secondarie) | Trasversali, non attraversano i liquidi | 3-5 km/s nella crosta |
| **Onde di superficie** (Love, Rayleigh) | Si propagano in superficie, causano i danni maggiori | 2-4 km/s |

### Misura dei terremoti

- **Magnitudo** (storicamente scala Richter, oggi Magnitudo momento Mw): misura l'energia rilasciata. È una scala logaritmica: un aumento di 1 grado corrisponde a circa 32 volte più energia
- **Intensità** (scala Mercalli MCS): misura gli effetti su persone, edifici e territorio. Dipende dalla profondità, dalla distanza e dal tipo di suolo

### Il contesto sismico dei Castelli Romani

L'area dei Castelli Romani presenta una **sismicità di livello medio** (zona 2B della classificazione sismica nazionale). La sismicità è legata sia alla tettonica regionale sia all'attività residua del complesso vulcanico dei Colli Albani.

L'**INGV** monitora costantemente l'area attraverso una rete di sismografi. I dati sono consultabili in tempo reale su [terremoti.ingv.it](https://terremoti.ingv.it/).

### Attività: analisi di un evento sismico

Accedete al sito dell'INGV ([terremoti.ingv.it](https://terremoti.ingv.it/)) e selezionate un terremoto recente in Italia. Compilate la scheda:

| Parametro | Valore |
|---|---|
| Data e ora | |
| Localizzazione (coordinate e nome) | |
| Profondità ipocentrale | |
| Magnitudo (Mw o Ml) | |
| Distanza da Genzano di Roma | |
| Zona sismica dell'epicentro | |
| Sarebbe stato avvertito a Genzano? (stima) | |

---

## Modulo 3 — Rischio idrogeologico e cambiamenti climatici

### Il dissesto idrogeologico in Italia

L'Italia è uno dei Paesi europei più esposti al rischio idrogeologico. Secondo i dati ISPRA:
- Il **94% dei comuni italiani** è a rischio per frane, alluvioni o erosione costiera
- Oltre **8 milioni di persone** vivono in aree a rischio elevato o molto elevato

Le cause sono sia naturali (geologia, morfologia, clima) sia antropiche (urbanizzazione, consumo di suolo, abbandono delle aree montane, mancata manutenzione).

### Frane e alluvioni nel territorio

Il territorio di Genzano e dei Castelli Romani presenta:
- **Versanti collinari** su substrato vulcanico (tufi) soggetti a fenomeni di erosione e frane superficiali
- **Fossi e impluvi** che in caso di piogge intense possono generare allagamenti localizzati
- **Aree urbanizzate** su pendio, con superfici impermeabilizzate che aumentano il deflusso superficiale

La piattaforma [IdroGEO](https://idrogeo.isprambiente.it/) di ISPRA consente di visualizzare le aree a rischio frana e alluvione su tutto il territorio nazionale, compreso il dettaglio comunale.

### Cambiamenti climatici ed eventi estremi

I dati scientifici mostrano che i cambiamenti climatici stanno modificando la frequenza e l'intensità degli eventi meteorologici:
- Aumento delle **ondate di calore** in durata e intensità
- Maggiore frequenza di **precipitazioni intense e concentrate** nel tempo
- Periodi di **siccità** più prolungati, che aumentano il rischio incendi e riducono la capacità del suolo di assorbire le piogge successive
- Innalzamento delle temperature medie che modifica i regimi pluviometrici

Queste tendenze non causano direttamente i disastri, ma **amplificano la vulnerabilità** dei territori e delle comunità.

### Attività: analisi territoriale con IdroGEO

Accedete alla piattaforma [IdroGEO](https://idrogeo.isprambiente.it/) e cercate il comune di Genzano di Roma.

1. Quante frane sono censite nel territorio comunale?
2. Esistono aree a pericolosità idraulica vicino alla scuola o alla vostra abitazione?
3. Confrontate la mappa con quella delle [aree di emergenza](/cartografia/) del Piano comunale: le aree di attesa sono in zone sicure?

---

## Modulo 4 — Il sistema di monitoraggio e allertamento

### La rete di monitoraggio

L'Italia dispone di una rete capillare di strumenti di monitoraggio:

| Rete | Ente | Cosa monitora |
|---|---|---|
| Rete Sismica Nazionale | INGV | Terremoti in tempo reale |
| Rete radar meteorologica | DPC | Precipitazioni |
| Rete pluviometrica e idrometrica | Centri Funzionali regionali | Pioggia e livelli dei corsi d'acqua |
| Rete GPS e geodetica | INGV | Deformazioni del suolo |
| Satelliti Copernicus | UE/ESA | Osservazione della Terra |
| Stazioni ARPA | ARPA regionali | Qualità dell'aria, inquinamento |

### Il processo di allertamento meteo-idrogeologico

**Fase 1 — Previsione**: i modelli meteorologici elaborano scenari a 24-72 ore. Il DPC emette il **Bollettino di Vigilanza Meteorologica** nazionale.

**Fase 2 — Valutazione**: il **Centro Funzionale Regionale** del Lazio analizza gli effetti previsti sul territorio regionale, considerando la vulnerabilità locale (stato del suolo, portata dei fiumi, frane pregresse).

**Fase 3 — Allertamento**: la Regione emette il bollettino di allerta con il codice colore (verde, giallo, arancione, rosso) per ciascuna **zona di allerta** e per ciascun **tipo di rischio**.

**Fase 4 — Attivazione locale**: il Sindaco attiva le procedure previste dal Piano (apertura COC, presidio del territorio, informazione alla popolazione). I volontari si rendono disponibili per il monitoraggio e l'assistenza.

### Le zone di allerta del Lazio

Il territorio laziale è suddiviso in zone di allerta omogenee per caratteristiche meteo-climatiche e idrogeologiche. Genzano di Roma ricade nella zona che comprende i Castelli Romani e parte della provincia sud di Roma.

### Strumenti di monitoraggio consultabili online

| Strumento | URL | Cosa mostra |
|---|---|---|
| Piattaforma Radar DPC | [mappe.protezionecivile.gov.it](https://mappe.protezionecivile.gov.it/it/mappe-e-dashboard-rischi/piattaforma-radar/) | Precipitazioni in tempo reale |
| AEGIS Regione Lazio | [temporeale.regione.lazio.it](https://temporeale.regione.lazio.it/aegis/map/map2d) | Idrometri, pluviometri, dati meteo regionali |
| INGV Terremoti | [terremoti.ingv.it](https://terremoti.ingv.it/) | Sismicità in tempo reale |
| EUMETSAT | [view.eumetsat.int](https://view.eumetsat.int/) | Immagini satellitari |
| Copernicus EMS | [mapping.emergency.copernicus.eu](https://mapping.emergency.copernicus.eu/) | Mappatura satellitare emergenze |

### Attività: simulazione di allerta

**Gioco di ruolo**: simulate la catena di allertamento. Assegnate i ruoli:
- Centro Funzionale Regionale (emette il bollettino)
- Sindaco (decide le azioni)
- Responsabile COC (coordina le risorse)
- Volontari (presidiano il territorio)
- Giornalisti (comunicano alla popolazione)
- Cittadini (reagiscono all'allerta)

**Scenario**: è prevista un'allerta arancione per rischio idrogeologico e temporali nelle prossime 24 ore. Piogge intense (50-80 mm in 6 ore) con possibili frane e allagamenti localizzati.

Ogni gruppo deve decidere le azioni da intraprendere e comunicarle. Alla fine, la classe valuta la risposta complessiva.

---

## Modulo 5 — Comunicazione del rischio

### Principi di risk communication

La comunicazione del rischio è una disciplina che studia come informare la popolazione sui pericoli in modo **efficace, tempestivo e non allarmistico**.

**Errori comuni nella comunicazione del rischio:**

| Errore | Esempio | Effetto |
|---|---|---|
| **Allarmismo** | "Arriva il terremoto devastante!" | Panico, perdita di credibilità |
| **Minimizzazione** | "Non c'è niente di cui preoccuparsi" | Sottovalutazione, mancata preparazione |
| **Ambiguità** | "Potrebbe piovere un po'" (durante un'allerta arancione) | Confusione, mancata risposta |
| **Fonti non ufficiali** | Condivisione di previsioni di siti non istituzionali | Disinformazione |
| **Spettacolarizzazione** | Video di disastri senza contesto informativo | Ansia, assuefazione |

**Principi di una comunicazione efficace:**
- Usare fonti ufficiali e verificate (DPC, Regione, INGV, MeteoAM)
- Distinguere tra "previsto" e "in corso"
- Specificare sempre zona, durata e tipo di rischio
- Indicare i comportamenti di autoprotezione
- Usare un linguaggio chiaro, evitare tecnicismi non necessari
- Non diffondere informazioni non confermate

### Il ruolo dei social media

I social media possono essere uno strumento potente per diffondere informazioni di protezione civile, ma presentano anche rischi significativi:

**Opportunità:**
- Raggiungono rapidamente un grande numero di persone
- Permettono aggiornamenti in tempo reale
- Consentono l'interazione diretta con i cittadini

**Rischi:**
- Diffusione di notizie false o imprecise
- Amplificazione dell'allarmismo
- Condivisione di contenuti decontestualizzati
- "Effetto eco" che distorce la percezione del rischio

### Attività: analisi critica

Selezionate 3-4 post o articoli online relativi a un evento meteorologico o sismico recente. Per ciascuno, analizzate:

1. La fonte è ufficiale o attendibile?
2. I dati riportati sono corretti e verificabili?
3. Il tono è informativo, allarmistico o minimizzante?
4. Vengono indicati i comportamenti di autoprotezione?
5. Vengono distinti fatti da opinioni?
6. Riscrivete il messaggio in modo corretto e istituzionale

---

## Modulo 6 — Volontariato e cittadinanza attiva

{{< pittogramma src="/pittogrammi/arasaac/volontario.png" alt="Pittogramma: volontario di protezione civile" size="medium" >}}

### Il volontariato nel Codice della Protezione Civile

Il D.Lgs. 1/2018 riconosce il volontariato organizzato come **componente fondamentale** del Servizio Nazionale di Protezione Civile (art. 31-42).

**I numeri:**
- Oltre **300.000 volontari** in Italia
- Circa **5.000 organizzazioni** iscritte agli albi regionali
- Operativi su tutto il territorio nazionale, anche in contesti internazionali

**Diritti dei volontari attivati:**
- Mantenimento del posto di lavoro durante le attivazioni
- Rimborso delle spese sostenute
- Copertura assicurativa per infortuni e responsabilità civile
- Formazione continua a carico del sistema

### Le attività del volontariato

| Ambito | Attività |
|---|---|
| **Previsione e prevenzione** | Monitoraggio del territorio, informazione alla popolazione, esercitazioni |
| **Soccorso** | Assistenza alla popolazione, ricerca dispersi, logistica, telecomunicazioni |
| **Post-emergenza** | Gestione campi, distribuzione materiali, supporto al ritorno alla normalità |
| **Formazione** | Corsi interni, esercitazioni, divulgazione nelle scuole |
| **Specializzazioni** | AIB, TLC radio, droni (APR), cinofilia, subacquea, NBCR |

### Il Gruppo di Genzano

Il Gruppo Comunale Volontari di Protezione Civile di Genzano di Roma opera nel territorio dei Castelli Romani con i seguenti settori:

- **Antincendio boschivo (AIB)** — lotta attiva e bonifica degli incendi
- **Telecomunicazioni** — comunicazioni radio in emergenza (collaborazione con ARI)
- **Logistica** — montaggio tende, gestione magazzino, distribuzione materiali
- **Divulgazione** — attività nelle scuole e sul territorio
- **APR (droni)** — ricognizione aerea per monitoraggio e ricerca

### PCTO e protezione civile

Le organizzazioni di volontariato di protezione civile possono ospitare studenti in **Percorsi per le Competenze Trasversali e per l'Orientamento** (ex alternanza scuola-lavoro).

**Competenze acquisibili:**
- Lavoro di squadra in contesti operativi
- Comunicazione efficace in situazioni di pressione
- Risoluzione dei problemi e gestione dell'imprevisto
- Competenze tecniche (radio, cartografia, primo soccorso, logistica)
- Responsabilità civica e senso della comunità

Per informazioni sui PCTO con il Gruppo di Genzano, scrivi a [segreteria@protezionecivilegenzano.it](mailto:segreteria@protezionecivilegenzano.it).

### Attività: dibattito strutturato

**Tema**: *"La protezione civile è responsabilità di tutti o solo delle istituzioni?"*

Dividete la classe in due gruppi:
- **Gruppo A** sostiene che la responsabilità è principalmente delle istituzioni (Stato, Regioni, Comuni)
- **Gruppo B** sostiene che ogni cittadino ha un ruolo attivo nella riduzione del rischio

Ogni gruppo ha 15 minuti per preparare le argomentazioni, poi 5 minuti ciascuno per esporle, seguiti da 10 minuti di replica. La classe vota la posizione più convincente.

**Spunto**: l'art. 118 della Costituzione italiana prevede il principio di sussidiarietà orizzontale, per cui le istituzioni favoriscono l'autonoma iniziativa dei cittadini per lo svolgimento di attività di interesse generale.

### Attività: progetto finale

**Lavoro individuale o di gruppo**: realizzate un prodotto di comunicazione su un tema di protezione civile a vostra scelta. Formati possibili:
- Articolo giornalistico
- Video informativo (max 3 minuti)
- Infografica
- Presentazione multimediale
- Podcast

**Requisiti:**
- Fonti ufficiali citate correttamente
- Linguaggio chiaro e adatto al pubblico scelto
- Informazioni verificabili e aggiornate
- Indicazione dei comportamenti di autoprotezione

---

## Quiz di verifica

**1. Quale legge ha istituito il Servizio Nazionale di Protezione Civile?**
- a) D.Lgs. 1/2018
- b) L. 225/1992 ✔
- c) L. 996/1970

**2. Le tipologie di eventi emergenziali previste dal Codice sono:**
- a) Tre: tipo a, b e c ✔
- b) Due: ordinari e straordinari
- c) Quattro: locale, provinciale, regionale e nazionale

**3. Le onde sismiche P sono:**
- a) Onde trasversali che si propagano solo nei solidi
- b) Onde di compressione che si propagano in tutti i materiali ✔
- c) Onde di superficie che causano i danni maggiori

**4. La magnitudo di un terremoto misura:**
- a) I danni causati agli edifici
- b) L'energia rilasciata ✔
- c) La durata della scossa

**5. Quale percentuale dei comuni italiani è a rischio idrogeologico?**
- a) Circa il 50%
- b) Circa il 94% ✔
- c) Circa il 30%

**6. I cambiamenti climatici influenzano il rischio idrogeologico perché:**
- a) Causano direttamente frane e alluvioni
- b) Amplificano la vulnerabilità del territorio aumentando frequenza e intensità degli eventi estremi ✔
- c) Non hanno alcuna relazione con il rischio idrogeologico

**7. Nella comunicazione del rischio, quale principio è fondamentale?**
- a) Usare un linguaggio tecnico per sembrare autorevoli
- b) Enfatizzare il pericolo per attirare l'attenzione
- c) Usare fonti ufficiali, distinguere tra previsto e in corso, indicare i comportamenti corretti ✔

**8. Il principio di sussidiarietà in protezione civile prevede che:**
- a) Lo Stato gestisce sempre tutte le emergenze
- b) La prima risposta parte dal livello più vicino al cittadino ✔
- c) I volontari non hanno competenze decisionali

**9. L'art. 118 della Costituzione prevede:**
- a) L'obbligo di leva per le emergenze
- b) Il principio di sussidiarietà orizzontale ✔
- c) Il divieto di volontariato nelle emergenze

**10. I PCTO con le organizzazioni di protezione civile permettono di sviluppare:**
- a) Solo competenze tecniche
- b) Competenze trasversali come lavoro di squadra, risoluzione dei problemi e responsabilità civica ✔
- c) Solo conoscenze teoriche sul diritto delle emergenze

---

## Modulo 7 — Sicurezza nei luoghi di lavoro (L. 21/2025) {#modulo-sicurezza-lavoro}

{{< pittogramma src="/pittogrammi/iso7010/casco-protettivo.svg" alt="Pittogramma ISO 7010 — Obbligo di indossare il casco protettivo" size="medium" >}}

### Quadro normativo specifico

La **Legge 17 febbraio 2025, n. 21** (in vigore dal 19 marzo 2025) ha aggiunto la **lettera h-ter)** all'art. 3 della Legge 92/2019. L'articolo include ora tra i temi obbligatori dell'Educazione Civica le *"conoscenze di base in materia di sicurezza nei luoghi di lavoro"*. L'insegnamento rientra nelle 33 ore annuali e interessa in modo particolare la Secondaria di II grado e i percorsi PCTO.

Il riferimento sostanziale resta il **D.Lgs. 9 aprile 2008, n. 81** — *Testo Unico sulla salute e sicurezza nei luoghi di lavoro*, che disciplina obblighi, figure, valutazione del rischio, formazione e DPI.

Il modulo si raccorda esplicitamente con i [Percorsi didattici pronti — Percorso 6 «Sicurezza nei luoghi di lavoro e PCTO»](/formazione/percorsi-didattici/#percorso-6).

### Perché un modulo dedicato in un kit di Protezione Civile

Sicurezza nei luoghi di lavoro e Protezione Civile condividono una stessa **logica di gestione del rischio**: identificazione del pericolo, valutazione, eliminazione alla fonte, protezione collettiva, protezione individuale, formazione, sorveglianza. Un volontario in attivazione di emergenza opera in condizioni operative complesse (cantiere allagato, area sismica, fronte di incendio): la cultura della sicurezza è il presupposto della cultura dell'autoprotezione.

### Le figure del D.Lgs. 81/2008

| Figura | Compito principale |
|---|---|
| **Datore di lavoro** | Titolare del rapporto, responsabile ultimo della sicurezza |
| **RSPP** (Responsabile del Servizio di Prevenzione e Protezione) | Coordina la valutazione dei rischi, supporta il datore di lavoro |
| **RLS** (Rappresentante dei Lavoratori per la Sicurezza) | Eletto dai lavoratori, vigila e propone migliorie |
| **Medico competente** | Sorveglianza sanitaria sui rischi specifici |
| **Preposto** | Sovrintende, controlla l'osservanza degli obblighi sui lavoratori |
| **Lavoratore** | Si prende cura della propria salute e di quella altrui (art. 20) |

Nella **scuola** il datore di lavoro è il **Dirigente Scolastico**; gli studenti sono equiparati a lavoratori quando svolgono attività di laboratorio, officina, palestra (D.M. 382/1998 + chiarimenti).

### I principi generali di prevenzione (art. 15 D.Lgs. 81/2008)

In ordine di priorità:

1. **Eliminazione del rischio alla fonte** (rimuovere il pericolo).
2. **Sostituzione** di ciò che è pericoloso con ciò che non lo è o lo è meno.
3. **Riduzione del rischio** alla fonte (es. miglior progettazione).
4. **Protezione collettiva** (barriere, schermi, aspirazione) prima di quella individuale.
5. **Dispositivi di Protezione Individuale (DPI)** come ultima linea.
6. **Formazione, informazione, addestramento** dei lavoratori.
7. **Sorveglianza sanitaria** quando necessaria.

> ⚠️ Il DPI non è la prima soluzione: è l'ultima. Una scuola di pensiero del lavoro che mette il DPI al posto della rimozione del rischio sta facendo prevenzione **al ribasso**.

### Dispositivi di Protezione Individuale (DPI)

I DPI si dividono in **3 categorie** (Reg. UE 2016/425):
- **Categoria I** — rischi minori (es. guanti per pulizia, occhiali da sole).
- **Categoria II** — rischi medi (es. caschi da cantiere, scarpe antinfortunistiche).
- **Categoria III** — rischi gravi o mortali (es. autorespiratori, imbracature anti-caduta, DPI per agenti chimici).

I DPI di Cat. III richiedono **formazione specifica obbligatoria** prima dell'uso.

### I principali rischi nei contesti di tirocinio/PCTO

| Rischio | Dove si incontra | Misure tipiche |
|---|---|---|
| **Caduta dall'alto** | Cantieri, manutenzione, palchi | Linee vita, parapetti, imbracature (Cat. III) |
| **Elettrico** | Officine, laboratori, cantieri | Verifiche periodiche, isolamento, cartelli W012 |
| **Chimico** | Laboratori, parrucchieri, agricoltura | Schede dati di sicurezza, aspirazione, DPI |
| **Biologico** | Sanitario, veterinario, agricoltura | Vaccinazioni, DPI, igiene rigorosa |
| **Movimentazione manuale carichi** | Logistica, sanità, ristorazione | Formazione tecnica di sollevamento, attrezzature |
| **Videoterminali** | Uffici, programmazione | Pause, postura, sorveglianza visiva |
| **Rumore** | Officine, cantieri, musica | DPI udito, valutazione esposizione |
| **Stress lavoro-correlato** | Ovunque | Valutazione, organizzazione del lavoro |

Per i **PCTO**, la scuola e l'ente ospitante devono identificare in convenzione i rischi specifici e la formazione necessaria **prima** dell'avvio dello studente.

### Infortuni e malattie professionali

- **Infortunio sul lavoro**: evento traumatico avvenuto per causa violenta in occasione di lavoro, da cui deriva inabilità temporanea o permanente. Va denunciato all'**INAIL** entro 2 giorni.
- **Malattia professionale**: alterazione dello stato di salute connessa all'esposizione lavorativa nel tempo (es. silicosi, ipoacusia da rumore). Riconoscimento INAIL su tabella o caso per caso.

### La segnaletica di sicurezza (Titolo V D.Lgs. 81/2008 + ISO 7010)

I cartelli di sicurezza adottano la norma **ISO 7010** anche in Italia (recepita via D.Lgs. 81/2008 — Titolo V allegato XXV). Le **5 categorie** si distinguono per **forma e colore** (non solo colore: criterio di accessibilità):

| Categoria | Forma | Colore | Esempi |
|---|---|---|---|
| **Divieto** (P-prohibition) | Cerchio con barra | Rosso | Divieto di fumare, vietato l'accesso |
| **Avvertimento** (W-warning) | Triangolo | Giallo | Pericolo elettrico, pericolo caduta |
| **Obbligo** (M-mandatory) | Cerchio | Blu | Obbligo casco, obbligo guanti |
| **Salvataggio** (E-emergency) | Quadrato/rettangolo | Verde | Uscita di emergenza, punto di raccolta |
| **Antincendio** (F-fire) | Quadrato/rettangolo | Rosso | Estintore, idrante |

Nel sito sono disponibili pittogrammi ISO 7010: vedi [/pittogrammi/](/pittogrammi/).

### Connessione con la Protezione Civile

I volontari del Gruppo, quando attivati in emergenza, applicano le stesse logiche del D.Lgs. 81/2008:
- DPI di Cat. III per attività AIB (tute Nomex, elmetti, occhiali, guanti).
- Linea di comando e principio della **catena di comando unica** (analogo al ruolo del preposto).
- Procedura di **riunione informativa e debriefing** per ogni intervento (analogo alla formazione operativa).
- **Valutazione del rischio sul posto** prima di entrare in scena.

Il volontariato di Protezione Civile è un **laboratorio civico di cultura della sicurezza**: chi vi partecipa porta nel resto della propria vita lavorativa l'attitudine alla prevenzione.

### Attività in classe

**Attività 1 — Audit di sicurezza della propria aula/laboratorio (1 ora)**
Gli studenti, in gruppi di 3, percorrono fisicamente la propria aula o un laboratorio dell'istituto e producono una **scheda di audit** semplificata che identifica: cartelli presenti/assenti rispetto agli obblighi; presenza/assenza di DPI; vie di fuga libere o ostruite; estintori in posizione e in scadenza. Confronto in plenaria con i rilievi del **RSPP** dell'istituto.

**Attività 2 — Caso studio "chi è responsabile?" (45 min)**
Si presentano 3 brevi casi (un infortunio in officina scolastica, una caduta in palestra, una contaminazione chimica in laboratorio) e si chiede agli studenti di **mappare le responsabilità** secondo il D.Lgs. 81/2008 (datore di lavoro/dirigente, RSPP, preposto, lavoratore/studente). Discussione: la responsabilità è **distribuita**, non concentrata.

**Attività 3 — Procedura Operativa Standard (compito di realtà, 2 ore)**
Gli studenti producono una **POS** sintetica per un'attività della propria scuola (es. uso del torchio in laboratorio di stampa, sollevamento attrezzi in palestra, uso del bunsen in chimica). La POS deve includere: scopo, campo di applicazione, riferimenti normativi, sequenza operativa, DPI obbligatori, riferimenti di emergenza. Restituzione al RSPP per validazione formale (può alimentare la **documentazione di sicurezza** dell'istituto, con valore concreto oltre la valutazione scolastica).

**Attività 4 — Testimonianza diretta (1 ora, opzionale)**
La L. 21/2025 incoraggia esplicitamente l'uso di **testimonianze dirette di vittime di infortuni** sul lavoro. È possibile invitare un volontario del Gruppo che racconti un infortunio reale (proprio o altrui) accaduto in attivazione di emergenza e analizzato a posteriori per le lezioni apprese — modalità coerente con la cultura del **debriefing** della Protezione Civile.

### Obiettivi di valutazione del modulo (rubrica)

Indicatori della [Rubrica Ed. Civica — Secondaria II](/formazione/schede-stampabili/rubrica-valutativa-secondaria2/):
- **Indicatore 1** (autoprotezione): conoscenza dei DPI e delle regole base.
- **Indicatore 5** (ruolo delle istituzioni): conoscenza delle figure D.Lgs. 81/2008 e dell'INAIL.
- **Indicatore 6** (cittadinanza attiva): capacità di produrre una POS o un audit utile alla scuola.

### Verifica del modulo (5 quesiti integrativi)

**M7-1.** *Tra i principi generali di prevenzione, qual è la priorità più alta?*
- a) Fornire DPI a tutti i lavoratori
- b) Eliminare il rischio alla fonte ✔
- c) Sorvegliare la salute dei lavoratori

**M7-2.** *Qual è la differenza fra protezione collettiva e DPI?*
- a) Nessuna, sono sinonimi
- b) La protezione collettiva agisce sull'ambiente per tutti, il DPI sul singolo lavoratore ✔
- c) La protezione collettiva è obbligatoria, il DPI è facoltativo

**M7-3.** *Nella scuola, chi è equiparabile al "datore di lavoro" del D.Lgs. 81/2008?*
- a) Il consiglio di classe
- b) Il dirigente scolastico ✔
- c) Lo studente maggiorenne

**M7-4.** *Cosa introduce la Legge 21/2025?*
- a) Un nuovo numero di emergenza
- b) Le conoscenze di base in materia di sicurezza nei luoghi di lavoro nell'Educazione Civica ✔
- c) Una rubrica valutativa nazionale unica

**M7-5.** *Un cartello triangolare giallo con il simbolo della folgore segnala:*
- a) L'obbligo di indossare guanti dielettrici
- b) Un avvertimento di pericolo elettrico ✔
- c) Un divieto di accesso

---

## Percorso PCTO strutturato con il Gruppo

I percorsi di **formazione scuola-lavoro**, fino al 2024/25 chiamati Percorsi per le Competenze Trasversali e l'Orientamento (D.Lgs. 77/2005; L. 145/2018, art. 1, commi 784-785; D.L. 127/2025), con il Gruppo Comunale di Protezione Civile di Genzano sono un'opportunità formativa concreta, coerente con gli obiettivi dei licei (90 ore nel triennio) e degli istituti tecnici/professionali (150-210 ore).

### Profilo del PCTO

**Titolo**: *"Cittadino resiliente — formazione e servizio con la Protezione Civile comunale"*

**Monte ore complessivo**: 30-50 ore (adattabile)

**Periodo**: possibile distribuzione in un semestre o in formula intensiva estiva

**Numero studenti**: 2-8 per convenzione (per garantire qualità del tutoraggio)

**Tutor interno**: docente della scuola (preferibilmente di scienze, geografia o ed. civica)

**Tutor esterno**: volontario del Gruppo con esperienza formativa

### Articolazione tipo (35 ore)

| Fase | Attività | Ore |
|---|---|---|
| 1. Formazione base | Normativa, sistema PC italiano, rischi del territorio | 6 |
| 2. Sicurezza | Corso di sicurezza generale (4 ore) + specifica 4 ore (se previsto contatto con mezzi) | 8 |
| 3. Osservazione | Partecipazione a riunioni di Gruppo, giornate formative interne | 4 |
| 4. Progetto | Realizzazione di un prodotto di comunicazione/sensibilizzazione | 12 |
| 5. Presentazione | Evento pubblico (scuola, quartiere, social) con presentazione del prodotto | 3 |
| 6. Valutazione | Autovalutazione, valutazione tutor interno, valutazione tutor esterno | 2 |

### Attività possibili (proposte modulari)

- **Redazione giornalistica interna**: articoli per il sito del Gruppo su temi di protezione civile (con tutoraggio redazionale)
- **Grafica e comunicazione**: produzione di infografiche, post social, video brevi per la campagna *Io non rischio*
- **Cartografia e GIS**: mappatura di elementi di rischio o di interesse (idranti, aree attesa, caditoie) con strumenti QGIS o uMap
- **Radio e telecomunicazioni**: affiancamento al settore TLC per l'apprendimento delle basi delle radiocomunicazioni di emergenza
- **Formazione nelle scuole**: supporto ai volontari durante gli interventi nelle scuole primarie (peer education)
- **Gestione eventi**: supporto organizzativo in esercitazioni ed eventi pubblici del Gruppo
- **Accessibilità e inclusione**: traduzione/adattamento di materiali per target specifici (anziani, persone con disabilità, stranieri)
- **Digital storytelling**: produzione di un documentario breve sul volontariato locale

### Competenze acquisibili (output attesi)

- **Competenze tecniche specifiche**: basi di radiocomunicazioni, cartografia, primo soccorso, gestione logistica di un evento
- **Competenze comunicative**: comunicazione pubblica, comunicazione istituzionale, redazione tecnica
- **Competenze trasversali**: lavoro di squadra, gestione del tempo, risoluzione dei problemi, resilienza
- **Competenze civiche**: responsabilità, sussidiarietà, partecipazione attiva

### Valutazione PCTO

La valutazione segue il **D.Lgs. 62/2017** con rubrica condivisa tra tutor interno ed esterno. Le evidenze concorrono al **Curriculum dello studente** e alla valutazione del comportamento.

### Convenzione

La convenzione tra la scuola e il Gruppo va sottoscritta prima dell'avvio delle attività. Contiene: oggetto, durata, obblighi delle parti, copertura assicurativa (già prevista dal Gruppo), modalità di valutazione. Il modello è disponibile su richiesta alla segreteria.

---

> 🔬 **Esperimenti e attività pratiche.** Collega le UdA agli [esperimenti di protezione civile](/formazione/esperimenti/): per le superiori sono adatti gli esperimenti più scientifici — **viscosità ed eruzioni**, **erosione e consumo di suolo**, **diffusione di una nube** e **distanza e schermatura** (i principi della radioprotezione).

## Schede fotocopiabili pronte per la stampa

<div class="alert alert-success" role="note">
<p class="mb-1"><i class="bi bi-printer-fill me-2" aria-hidden="true"></i><strong>Schede già pronte per la stampa</strong></p>
<p class="mb-0">Diverse schede sono già pronte: apri, premi <kbd>Stampa</kbd> del browser (Ctrl+P o Cmd+P) e ottieni un foglio A4 perfetto con intestazione istituzionale. Pensate per la scuola secondaria di secondo grado.
👉 <strong><a href="/formazione/schede-stampabili/">Vai all'elenco delle schede stampabili</a></strong> (in continuo arricchimento).
Per richieste specifiche: <a href="mailto:segreteria@protezionecivilegenzano.it">segreteria@protezionecivilegenzano.it</a>.</p>
</div>

Schede pronte per la stampa specifiche per la scuola secondaria di secondo grado:

- 👉 [**Caso studio Amatrice 2016**](/formazione/schede-stampabili/caso-amatrice-secondaria2/) — analisi sistemica del terremoto del Centro Italia 2016: dati essenziali, domande approfondite (fenomeno fisico, fattori predisponenti, risposta, criticità, lezione, riflessione personale).
- 👉 [**Comunicazione di crisi**](/formazione/schede-stampabili/comunicazione-crisi-secondaria2/) — lo studente è il responsabile comunicazione del Comune durante un'allerta arancione. Produce 3 testi: post social, messaggio Telegram, nota stampa. Vincoli e griglia di valutazione.
- 👉 [**Tracce per la prima prova d'esame**](/formazione/schede-stampabili/traccia-esame-secondaria2/) — tracce nello stile della prima prova di Stato (Beck, Ischia 2022, IT-alert, art. 2 D.Lgs. 1/2018, volontariato). 2 di Tipologia B, 3 di Tipologia C.
- 👉 [**Blackout e servizi essenziali**](/formazione/schede-stampabili/blackout-servizi-essenziali-secondaria/) — disagio, urgenza ed emergenza: piano familiare in caso di interruzione di luce, telefono o acqua. box "Prima/Durante/Comunicazioni/Quando chiamare", attività domestiche, mini quiz. Adatta anche al secondo grado per il taglio cittadinanza/resilienza. *(ed. civica, tecnologia)*
- 👉 [**Monossido di carbonio**](/formazione/schede-stampabili/monossido-carbonio-secondaria/) — sicurezza domestica e prevenzione del pericolo invisibile in case, garage e locali chiusi: caldaie, stufe, barbecue. Caccia al rischio in casa, regole per ogni apparecchio, mini quiz. *(scienze, tecnologia, ed. civica)*
- 👉 [**Maremoto: la fisica e i comportamenti**](/formazione/schede-stampabili/maremoto-comportamenti-secondaria/) — la propagazione dell'onda (700-800 km/h in mare aperto, rallenta e cresce in costa), il Sistema di Allertamento SiAM, i tre segnali naturali, i comportamenti di autoprotezione. Collegamento al caso Messina 1908. Mini verifica e soluzioni. *(scienze, geografia, ed. civica)*
- 👉 [**IT-alert e comunicazioni ufficiali**](/formazione/schede-stampabili/it-alert-comunicazioni-secondaria/) — sistema nazionale di allarme pubblico: tabella dei 5 elementi del messaggio operativo, esempio realistico, attività di scrittura per il territorio, mini quiz. *(ed. civica, cittadinanza digitale, italiano)*
- 👉 [**Notizie false in emergenza**](/formazione/schede-stampabili/fake-news-emergenza-secondaria/) — disinformazione e comunicazione del rischio: regola dei 3 controlli, checklist "prima di condividere", riscrittura di un messaggio allarmistico in forma corretta, mini quiz. *(ed. civica digitale, italiano, sociologia della comunicazione)*
- 👉 [**La siccità e i dati del clima locale**](/formazione/schede-stampabili/siccita-dati-clima-secondaria2/) — analisi guidata della serie di pioggia annua di Genzano (rianalisi ERA5 via Open-Meteo): deficit idrico, differenza fra siccità meteorologica e idrologica, la siccità come rischio che cresce. *(scienze della Terra, geografia, statistica, ed. civica)*
- 👉 [**Emergenza inclusiva**](/formazione/schede-stampabili/emergenza-inclusiva-secondaria2/) — aiutare persone con disabilità, fragilità o bisogni specifici senza improvvisare: box "Chiedi/Comunica/Prepara/Rete", modello "scheda bisogni essenziali", verifica inclusiva del percorso, mini quiz. *(ed. civica, scienze umane, inclusione, diritto)*

**Schede curriculari trasversali** (diritto, scienze, economia, etica, inglese, ed. civica):

- 👉 [**Il Codice della Protezione Civile (D.Lgs. 1/2018)**](/formazione/schede-stampabili/codice-pc-secondaria2/) — analisi degli articoli chiave (artt. 1, 2, 6, 12, 18, 32-35), tabella delle autorità di PC per livello, domande di applicazione. *(diritto, ed. civica)*
- 👉 [**Tettonica delle placche e magnitudo**](/formazione/schede-stampabili/placche-tettoniche-secondaria2/) — placche, faglie, magnitudo Mw vs Richter, scala Mercalli, formula del momento sismico, domande di applicazione. *(scienze della Terra, fisica)*
- 👉 [**Cambiamento climatico e rischi mediterranei**](/formazione/schede-stampabili/climate-change-secondaria2/) — IPCC, dati italiani, 6 eventi recenti, mitigazione vs adattamento, costruzione grafico, domande. *(scienze, geografia)*
- 👉 [**Leggere un indicatore dell'Agenda 2030**](/formazione/schede-stampabili/indicatori-agenda2030-secondaria2/) — i traguardi 1.5, 11.5, 11.b e 13.1 nel testo ufficiale, gli indicatori in comune con il Quadro di Sendai, un esercizio di normalizzazione e un compito di realtà per il territorio. *(ed. civica, diritto, matematica, inglese CLIL)*
- 👉 [**I Nobel che ci proteggono**](/formazione/schede-stampabili/nobel-che-ci-proteggono-secondaria2/) — otto premi Nobel da abbinare agli strumenti della protezione civile, fatti, previsioni e opinioni, le scorciatoie della mente davanti al rischio, una motivazione da scrivere con la sua fonte. Si accompagna al [dossier interattivo](/dossier/i-nobel-che-ci-proteggono/). *(storia, fisica, scienze, ed. civica)*
- 👉 [**Economia del rischio: prevenire o ricostruire**](/formazione/schede-stampabili/economia-rischio-secondaria2/) — rapporto 1:5 prevenzione/ricostruzione, costi reali italiani, formula BCR, domande con quesito etico finale. *(economia, statistica)*
- 👉 [**Il caso L'Aquila 2009 — comunicazione di crisi**](/formazione/schede-stampabili/caso-aquila-secondaria2/) — il processo alla Commissione Grandi Rischi, dilemmi etici, principio di precauzione, domande con dilemma personale. *(diritto, etica)*
- 👉 [**English for Civil Protection**](/formazione/schede-stampabili/english-civil-protection-secondaria2/) — glossario tecnico inglese, lettura di un articolo internazionale (EU Civil Protection Mechanism), comprehension, gioco di ruolo emergency call. *(inglese L2)*
- 👉 [**Diventare volontario di PC**](/formazione/schede-stampabili/percorso-volontariato-secondaria2/) — requisiti, specialità, 7 step del percorso, diritti e doveri (D.Lgs. 1/2018), mini-progetto personale. *(ed. civica, orientamento)*

**12 nuovi caso studio** delle maxi-emergenze italiane (analisi sistemica con format «Cosa non andava / Cosa è cambiato / Lezioni apprese» + domande di analisi + box per il docente):

- 👉 [**Caso Messina-Reggio Calabria 1908**](/formazione/schede-stampabili/caso-messina-reggio-secondaria2/) — terremoto + tsunami, 80.000-120.000 vittime: la più grande catastrofe naturale d'Europa moderna, prima legge antisismica italiana. *(storia, scienze della Terra, italiano)*
- 👉 [**Caso Irpinia 1980**](/formazione/schede-stampabili/caso-irpinia-secondaria2/) — «Fate presto»: 2.914 vittime, soccorsi tardivi, nascita del Ministero della Protezione Civile, percorso verso la legge 225/1992. *(storia, diritto, ed. civica)*
- 👉 [**Caso San Giuliano di Puglia 2002**](/formazione/schede-stampabili/caso-san-giuliano-secondaria2/) — la scuola Jovine crollata: 27 bambini + maestra, OPCM 3274/2003, classificazione sismica obbligatoria di tutto il territorio. *(diritto, scienze della Terra, ed. civica, etica)*
- 👉 [**Caso Vajont 1963**](/formazione/schede-stampabili/caso-vajont-secondaria2/) — la "tragedia annunciata": frana del Toc, 1.917 vittime, ruolo della responsabilità tecnica e della comunicazione del rischio. *(geologia, diritto, filosofia, italiano)*
- 👉 [**Caso Friuli 1976**](/formazione/schede-stampabili/caso-friuli-secondaria2/) — «Là dov'era, com'era»: 989 vittime, ricostruzione modello, nascita della PC italiana moderna. *(storia, diritto, ed. civica)*
- 👉 [**Caso Vermicino 1981**](/formazione/schede-stampabili/caso-vermicino-secondaria2/) — Alfredino Rampi, 18 ore di diretta TV, l'opinione pubblica scopre la PC: nasce il Ministero. *(storia, diritto, comunicazione, etica)*
- 👉 [**Caso Stava 1985**](/formazione/schede-stampabili/caso-stava-secondaria2/) — frana dei bacini di decantazione minerari, 268 vittime: il rischio industriale e la responsabilità penale. *(diritto, geologia, etica industriale)*
- 👉 [**Caso Versilia 1996**](/formazione/schede-stampabili/caso-versilia-secondaria2/) — alluvione di Cardoso, 14 vittime: bombe d'acqua, bacini montani, cambiamento climatico. *(geografia, geologia, ed. civica)*
- 👉 [**Caso Sarno 1998**](/formazione/schede-stampabili/caso-sarno-secondaria2/) — frana di fango, 161 vittime: urbanizzazione fragile e nascita dei PAI. *(geologia, diritto, geografia)*
- 👉 [**Caso Rigopiano 2017**](/formazione/schede-stampabili/caso-rigopiano-secondaria2/) — valanga sull'hotel, 29 vittime: comunicazione del rischio fallita, catena decisionale frammentata. *(diritto, ed. civica, comunicazione)*
- 👉 [**I vulcani attivi italiani**](/formazione/schede-stampabili/caso-vulcani-italia-secondaria2/) — Vesuvio, Campi Flegrei, Etna, Stromboli, Vulcano, Marsili, Ischia: pericolosità, monitoraggio INGV, piani di emergenza. *(scienze della Terra, geografia, diritto)*
- 👉 [**Bradisismo dei Campi Flegrei**](/formazione/schede-stampabili/caso-campi-flegrei-secondaria2/) — caso in evoluzione: sciami sismici, livello giallo INGV, decreto Campi Flegrei 2023, esercitazione EXE Flegrei. Da aggiornare con i bollettini settimanali INGV. *(scienze della Terra, comunicazione, diritto)*

**Schede del curricolo a spirale 6-19 anni — versione Secondaria II** (stessi temi disponibili anche per Primaria e Secondaria I, per scelta del docente):

- 👉 [**Analisi critica di tre bollettini**](/formazione/schede-stampabili/decodifica-bollettino-secondaria2/) — tre bollettini reali (giallo/arancione/rosso) della Regione Lazio: analisi linguistica, calcoli quantitativi, critica costruttiva, riformulazione come post Instagram in 280 caratteri. *(italiano, scienze della Terra, ed. civica)*
- 👉 [**Mappa rischi GIS + proposta mitigazione**](/formazione/schede-stampabili/mappa-rischi-secondaria2/) — approccio GIS semplificato: formula R = P × V × E, costruzione mappa, identificazione popolazione fragile, mitigazione strutturale e organizzativa, segnalazione formale al Comune. *(geografia, scienze, tecnologia)*
- 👉 [**Piano emergenza condominio o scuola**](/formazione/schede-stampabili/piano-familiare-secondaria2/) — progetto completo per un edificio reale: ruoli, vie di fuga, scenari (incendio/sisma/allagamento), persone con mobilità ridotta, vademecum A4. *(tecnologia, ed. civica)*
- 👉 [**Glossario commentato del lessico PC**](/formazione/schede-stampabili/cruciverba-secondaria2/) — 11 termini tecnici (allerta vs emergenza, magnitudo vs intensità, frana vs smottamento) con uso corretto + riformulazione di frasi giornalistiche errate. *(italiano, ed. civica)*
- 👉 [**Progetto piano di evacuazione di un edificio**](/formazione/schede-stampabili/labirinto-evacuazione-secondaria2/) — quadro normativo (D.Lgs. 81/2008, DM 3/8/2015), pianta in scala, calcoli dimensionamento, squadre emergenza, procedure scenari, scheda esercitazione. *(tecnologia, sicurezza)*
- 👉 [**Chiamata 112 — Analisi linguistica + protocollo**](/formazione/schede-stampabili/chiamo-112-secondaria2/) — modello SBAR ai 6 elementi, analisi 3 casi reali, sistema AML e implicazioni etiche, protocollo A4 per studenti delle scuole superiori. *(italiano, sicurezza, ed. civica)*

---

## Compito di realtà — Progetto di classe

In alternativa al PCTO (o a integrazione), proponi un **Progetto di classe** come compito di realtà valutabile in Educazione Civica.

### Progetto A — *"Il piano di evacuazione della mia scuola"*

**Consegna**: analizzare criticamente il Piano di Emergenza del proprio istituto e produrre una proposta di miglioramento.

**Fasi**
1. Richiesta formale al Dirigente Scolastico di accesso al Piano
2. Lettura e schematizzazione del Piano in classe
3. Verifica sul campo: percorsi di fuga effettivamente agibili? Cartelli presenti e leggibili? Punto di raccolta sicuro? Alunni informati?
4. Sondaggio anonimo a campione studenti e personale (chi sa cosa fare?)
5. Analisi dei dati (statistica descrittiva, grafici)
6. Redazione di un **report di proposta** al Dirigente e all'RSPP
7. Presentazione pubblica (Consiglio di Istituto, assemblea studentesca)

**Durata**: 12-15 ore distribuite in 2 mesi

**Prodotti**: report A4 di 15-20 pagine + presentazione + infografica riassuntiva

### Progetto B — *"Rischio e resilienza del mio quartiere"*

**Consegna**: mappare i rischi e le risorse di un quartiere o di una frazione di Genzano (o del territorio di appartenenza se la scuola è diversa) e produrre una guida informativa per i residenti.

**Fasi**
1. Analisi della cartografia ufficiale (PAI, IdroGEO, Piano di Emergenza Comunale)
2. Uscita sul territorio: mappatura elementi di rischio e risorse (idranti, aree sicure, servizi)
3. Intervista a residenti (con consenso documentato) sulla percezione del rischio
4. Redazione della guida (formato A5 piegato a 3 ante)
5. Distribuzione in farmacie, parrocchia, centri anziani (in accordo con Gruppo e Comune)

**Durata**: 15-20 ore

**Prodotti**: guida di 6-8 pagine formato pieghevole + mappa + versione digitale

### Progetto C — *"Una campagna come Io non rischio"*

**Consegna**: progettare una mini-campagna di comunicazione del rischio sul modello della campagna nazionale [Io non rischio](https://www.iononrischio.it/) per un target specifico (adolescenti, anziani, famiglie, turisti, stranieri).

**Fasi**
1. Analisi della campagna esistente (contenuti, messaggi, target)
2. Definizione del proprio target e dei bisogni informativi specifici
3. Progettazione dei contenuti (messaggio, canale, formato)
4. Produzione materiali (video, poster, post social, podcast)
5. Diffusione (scuola, social della scuola, rete dei familiari)
6. Valutazione dell'efficacia (sondaggio di retention)

**Durata**: 20-30 ore

**Prodotti**: kit completo di comunicazione + report sull'efficacia

---

## Percorsi pluridisciplinari per l'Esame di Stato

Il percorso si presta bene come **argomento pluridisciplinare** per il colloquio dell'Esame di Stato. Alcuni spunti collaudati.

### Tema "Rischio e responsabilità"

| Disciplina | Contributo |
|---|---|
| **Italiano** | Dino Buzzati, "Il deserto dei Tartari" (attesa della catastrofe); Calvino "Le città invisibili" (le città sul rischio) |
| **Storia** | Il Vajont (1963) come caso di responsabilità politica e scientifica |
| **Filosofia** | Jonas, "Il principio responsabilità" — l'etica per la civiltà tecnologica |
| **Scienze della Terra** | Classificazione dei rischi, valutazione della pericolosità |
| **Diritto** | Il processo Commissione Grandi Rischi dopo il sisma dell'Aquila |
| **Inglese** | Analisi del concetto di *risk society* (U. Beck) |

### Tema "Cambiamento climatico e territorio"

| Disciplina | Contributo |
|---|---|
| **Scienze** | Basi del cambiamento climatico (IPCC), eventi estremi in Italia |
| **Geografia** | Dissesto idrogeologico, consumo di suolo, urbanistica |
| **Diritto** | Legge sul consumo di suolo, Piano nazionale adattamento ai cambiamenti climatici |
| **Economia** | Costi economici dei disastri, assicurazioni, fondi europei (RescEU) |
| **Italiano** | Saviano "La paranza dei bambini" per gli aspetti di comunità e territorio |
| **Storia** | Alluvione di Firenze 1966, nascita del volontariato moderno |

### Tema "Comunicazione, media, cittadinanza"

| Disciplina | Contributo |
|---|---|
| **Italiano** | Retorica dell'allerta; testo informativo; disinformazione storica |
| **Storia** | Propaganda, allarmismi storici, panico di massa (Welles "La guerra dei mondi") |
| **Filosofia** | Filosofia del linguaggio, atti linguistici |
| **Informatica** | Algoritmi dei social, camera dell'eco |
| **Diritto** | Diritto all'informazione e limiti; libertà di stampa e responsabilità |
| **Scienze** | Caso studio: comunicazione del Covid-19, Ebola, terremoti |

---

## Rubrica di valutazione delle competenze

| Competenza | Iniziale (D) | Base (C) | Intermedio (B) | Avanzato (A) | Eccellenza (A+) |
|---|---|---|---|---|---|
| **Analisi critica del quadro normativo** | Superficiale | Riconosce i principali testi di legge | Collega norme e contesto storico | Valuta criticamente il sistema con esempi | Propone miglioramenti motivati e realizzabili |
| **Comprensione scientifica del rischio** | Frammentaria | Spiega i fenomeni base | Integra fenomeni e dati | Analizza scenari complessi | Formula ipotesi originali fondate su dati |
| **Ricerca e selezione fonti** | Non distingue le fonti | Usa fonti ufficiali se indicate | Seleziona autonomamente fonti di qualità | Confronta fonti, identifica bias | Costruisce bibliografia tecnica completa |
| **Comunicazione scritta e orale** | Testo confuso o errato | Testo corretto ma elementare | Testo chiaro e ben argomentato | Testo efficace, adatto al target | Testo con qualità giornalistica o tecnica pubblicabile |
| **Progettazione e realizzazione** | Non produce | Produce con guida costante | Produce autonomamente un prodotto semplice | Produce un prodotto completo e coerente | Produce un prodotto di qualità pubblica |
| **Cittadinanza attiva** | Passivo | Segue le iniziative | Partecipa attivamente | Propone iniziative realizzabili | Coordina iniziative coinvolgendo altri |
| **Lavoro di gruppo** | Ostacola | Contribuisce minimo | Contribuisce in modo costante | Favorisce la cooperazione | Assume ruoli di coordinamento |

**Conversione orientativa in decimi**: D=5, C=6, B=7-8, A=8-9, A+=10.

**Collocazione nella valutazione**: il percorso contribuisce alla valutazione di Educazione Civica (art. 2 Legge 92/2019), e in caso di PCTO contribuisce al voto di comportamento, al Curriculum dello studente e alla certificazione delle competenze.

---

## Adattamenti per l'inclusione

### Alunni con DSA

- Applica le misure compensative e dispensative del PDP
- Per l'analisi normativa fornisci sintesi ad alta leggibilità
- Per i dati scientifici fornisci sempre la rappresentazione grafica
- Valorizza la produzione orale e multimediale come alternativa alla scritta
- Per il PCTO: tempi distesi, tutoraggio individuale

### Alunni con disabilità intellettiva

- Collaborazione stretta con il docente di sostegno
- Obiettivi personalizzati in PEI: focus sulla **partecipazione significativa**, non sulla piena equivalenza con la classe
- Ruoli operativi chiari e definiti nei lavori di gruppo (es. ricerca immagini, registrazione audio, supporto logistico)
- Nel PCTO: valorizza mansioni adatte al profilo (archiviazione, supporto accoglienza, grafica semplice)

### Alunni con disturbo dello spettro autistico

- Struttura chiara e prevedibile delle attività
- Evita cambi di programma durante le uscite e le simulazioni
- Per i Debate, assegna il ruolo e le argomentazioni con anticipo
- Valorizza competenze specifiche (analisi dati, attenzione al dettaglio)

### Alunni con disabilità motoria

- Accessibilità di tutte le uscite verificata preventivamente
- Per il PCTO scegli attività fisicamente compatibili (redazione, grafica, comunicazione, archivio)

### Alunni stranieri con italiano L2

- Fornisci versioni semplificate dei testi normativi
- Valorizza la competenza plurilingue: possono tradurre materiali informativi per le comunità di origine
- Per il progetto di classe, l'analisi comparativa con il sistema di PC del paese di origine è una risorsa preziosa

### Alunni plusdotati

- Approfondimenti: lettura integrale del D.Lgs. 1/2018, report IPCC, sentenza Grandi Rischi L'Aquila
- Ruoli di coordinamento nei progetti di classe
- Pubblicazione dei lavori migliori sul sito del Gruppo (previo accordo)

---

## Raccordo con il Piano di Emergenza della Scuola

Il Piano di Emergenza e di Evacuazione della scuola (obbligatorio ai sensi di **D.M. 26/08/1992** e **D.Lgs. 81/2008**) è il documento istituzionale su cui si innestano molte attività del kit, in particolare:

- **Modulo 4 (Monitoraggio e allertamento)** → esemplifica con il sistema allerta interno alla scuola (allarme, voci di annuncio, SMS staff)
- **Progetto A (Piano di evacuazione)** → richiede accesso formale al Piano d'istituto
- **PCTO sezione sicurezza** → le 4-8 ore di formazione sicurezza sono direttamente funzionali al rispetto del **D.Lgs. 81/2008**
- **Esercitazioni di evacuazione** → integrare il percorso didattico con le prove obbligatorie (min. 2/anno)

**Azione operativa**: prima di avviare il percorso, richiedi un incontro con l'RSPP e il Dirigente Scolastico per concordare:
- Livello di accesso al Piano consentito agli studenti
- Coordinamento con la prova di evacuazione
- Eventuale presenza dell'RSPP come testimone qualificato per una lezione del Modulo 4
- Inserimento nel **Documento di Valutazione dei Rischi (DVR)** della scuola di eventuali attività che coinvolgono esterni (volontari del Gruppo)

---

## Coinvolgimento della famiglia e della comunità

### Assemblea di classe aperta ai genitori

Una volta l'anno, organizza un'assemblea di classe con i genitori (60-90 minuti) in cui gli studenti presentano il progetto di classe o i prodotti del PCTO. È un'occasione di restituzione alla comunità e di rafforzamento del patto scuola-famiglia.

### Eventi pubblici

I prodotti del progetto di classe (guida al rischio, campagna di comunicazione, report sul Piano scolastico) possono essere presentati in eventi pubblici:
- Giornata della Protezione Civile (seconda domenica di ottobre, "Io non rischio")
- Giornata aperta della scuola
- Eventi del Comune di Genzano (Sagra dell'Infiorata, eventi culturali)
- Assemblee di quartiere promosse dal Comitato di Quartiere

### Stampa locale

Gli elaborati migliori possono essere proposti alla stampa locale (siti e giornali dei Castelli Romani) come contenuti di interesse pubblico. Il Gruppo può fungere da referente per il contatto.

---

## FAQ del docente

**D. Nel mio istituto tecnico/professionale il PCTO è da 150-210 ore: un percorso con la PC copre tutto?**
R. Un PCTO con il Gruppo copre 30-50 ore. Le ore restanti vanno completate con altri enti. Il PCTO PC è un'ottima **esperienza qualificante** nel piano triennale dello studente, specialmente per indirizzi CAT, chimico-ambientale, elettrotecnico.

**D. Come gestisco uno studente interessato al volontariato "vero"?**
R. Gli studenti maggiorenni possono iscriversi direttamente al Gruppo. Gli studenti dai 16 anni possono farlo con il consenso del genitore o di chi esercita la responsabilità genitoriale, secondo il regolamento del Gruppo (vedi `/diventa-volontario/`); la piena operatività sul campo resta comunque al compimento dei 18 anni. Il PCTO può essere la porta di ingresso.

**D. Il processo Grandi Rischi dell'Aquila è un tema politicamente sensibile. Come lo affronto?**
R. Come un **caso di studio di diritto penale e di filosofia della scienza**. Fatti: condanne in primo grado, assoluzioni in appello (eccetto De Bernardinis), dibattito sul ruolo della scienza nella comunicazione del rischio. Il tema è ricchissimo per il colloquio di Esame di Stato perché attraversa diritto, filosofia, scienza, comunicazione.

**D. Come gestisco il negazionismo climatico tra gli studenti?**
R. Non è più un tema di "dibattito": le posizioni scientifiche sono univoche (IPCC). Il dibattito legittimo è su **come reagire** al cambiamento climatico, non sul fatto che esista. Distinguere fatto e scelta politica è un esercizio di cittadinanza.

**D. Posso usare le immagini di disastri?**
R. Sì, ma con uso didattico: con contestualizzazione storica, dati, analisi. Evita video spettacolari senza contesto. Mai immagini di corpi o di persone identificabili.

**D. La classe ha studenti reduci da esperienze traumatiche (es. famiglie di L'Aquila, Amatrice, Emilia)**
R. Coordinati con il docente referente BES/DSA e lo psicologo scolastico. Valorizza la loro esperienza se loro vogliono condividerla. Proteggili da esposizioni pubbliche non desiderate. Usa un tono calmo e rispettoso.

**D. Cosa succede se uno studente del PCTO partecipa a un'attivazione reale del Gruppo?**
R. Le attivazioni di emergenza **non fanno parte del PCTO** per motivi assicurativi e di ruolo. Lo studente PCTO non è un volontario operativo. L'attivazione reale è riservata ai volontari regolarmente iscritti e formati. Questo limite va spiegato chiaramente all'inizio del percorso.

**D. Le 33 ore di Ed. Civica + 50 ore di PCTO sono troppe per coprire solo protezione civile**
R. Infatti non coprono solo protezione civile. Il percorso può essere modulato: le 33 ore di Ed. Civica coprono diversi nuclei (cittadinanza digitale, Agenda 2030, Costituzione, protezione civile). Il PCTO è uno dei tanti possibili, da scegliere se coerente con il percorso di studi.

**D. Posso coinvolgere il Gruppo nella preparazione di un'esercitazione della scuola?**
R. Sì, è una delle collaborazioni più naturali. Il Gruppo può partecipare come **osservatore qualificato** della prova di evacuazione e fornire un debriefing tecnico al Dirigente e all'RSPP.

---

## Esempi aggiuntivi per PCTO, Esame di Stato e compiti di realtà

Materiale integrativo per docenti del secondo biennio e quinto anno. Include casi studio approfonditi, tracce per l'Esame di Stato, template per prodotti PCTO verificabili, esempi di dibattiti strutturati e progetti interdisciplinari di livello universitario.

### Casi studio approfonditi con analisi sistemica

Per ogni caso sono indicati: (1) fenomeno fisico, (2) fattori predisponenti, (3) risposta istituzionale, (4) criticità emerse, (5) lezione di sistema. Durata tipica: 3-4 ore di didattica + studio a casa.

**Caso 1 — Sequenza sismica Centro Italia 2016-2017 (Amatrice, Visso, Norcia)**

- *Fenomeno*: sequenza di oltre 70.000 scosse in 12 mesi, con 4 eventi principali M>5.5. Faglia distensiva Appenninica.
- *Fattori predisponenti*: patrimonio edilizio pre-normativa antisismica, spopolamento rurale, abbandono del territorio.
- *Risposta istituzionale*: attivazione DICOMAC, colonna mobile regionale, classificazione agibilità con scheda AeDES.
- *Criticità*: lentezza ricostruzione, frammentazione decisionale tra commissari, fatica a tenere insieme ricostruzione fisica e tessuto sociale.
- *Lezione*: la resilienza territoriale non si improvvisa al momento dell'evento, si costruisce nei decenni con manutenzione, pianificazione, cultura del rischio.

**Caso 2 — Frana di Ischia 26 novembre 2022**
- *Fenomeno*: colata rapida di fango e detriti innescata da 126 mm di pioggia in 6 ore. 12 vittime a Casamicciola Terme.
- *Fattori predisponenti*: abusivismo edilizio diffuso in aree classificate PAI (Piano Assetto Idrogeologico) come pericolosità elevata; 27.000 richieste di condono solo a Ischia; cambiamento climatico con precipitazioni sempre più estreme.
- *Risposta*: stato di mobilitazione nazionale, commissario straordinario, ricollocazione famiglie.
- *Criticità*: un condono sanato nel 2017 riguardava proprio un edificio in area a rischio.
- *Lezione*: rischio idrogeologico + abusivismo + clima = tragedia annunciata. Il cittadino ha il diritto ma anche la **responsabilità** di conoscere la classificazione di rischio della propria area.

**Caso 3 — Vaia ottobre-novembre 2018**
- *Fenomeno*: tempesta "Vaia" (medicane) con raffiche fino a 200 km/h che ha abbattuto 41.000 ettari di foreste tra Trentino, Veneto e Friuli.
- *Fattori predisponenti*: monoculture di abete rosso vulnerabili, cambiamento climatico, infrastruttura elettrica aerea.
- *Risposta*: rimozione 8 milioni di metri cubi di legname, prevenzione bostrico tipografo.
- *Criticità*: sottovalutata la portata dell'evento nei primi giorni; comunicazione locale carente.
- *Lezione*: in Italia si vive anche un **rischio forestale** e un **rischio da vento** che stanno crescendo col clima.

**Caso 4 — Terremoto L'Aquila 6 aprile 2009 e processo Grandi Rischi**
- *Fenomeno*: terremoto M 6.3, 309 vittime.
- *Caso giudiziario*: condanna in primo grado (poi assolti in appello) di 7 membri della Commissione Grandi Rischi per comunicazione del rischio inadeguata.
- *Lezione*: il ruolo della scienza nella comunicazione pubblica, limiti della previsione, responsabilità del decisore politico. Caso studio obbligatorio per ogni corso di risk communication.

### Tracce per l'Esame di Stato — 5 esempi per la prima prova

Tracce pronte nello stile della prima prova scritta dell'Esame di Stato (tipologia B — analisi di un testo argomentativo — e tipologia C — tema di attualità).

**Traccia 1 (Tipologia C — attualità)**: «Il 26 novembre 2022 una frana ha colpito Casamicciola Terme provocando 12 vittime. Nei mesi seguenti il dibattito pubblico si è concentrato sul rapporto tra pianificazione urbanistica, abusivismo edilizio e cambiamento climatico. Dopo aver analizzato le principali cause che concorrono al rischio idrogeologico in Italia, esprimi le tue considerazioni sul concetto di *responsabilità condivisa* tra Stato, enti locali e cittadini, anche alla luce dell'art. 18 del D.Lgs. 1/2018 ("doveri del cittadino").»

**Traccia 2 (Tipologia B — argomentativo)**: Testo di partenza: estratto da *La società del rischio* di Ulrich Beck (cap. 1). «Analizza il concetto di *rischio sistemico* proposto da Beck e confrontalo con quanto emerso durante la pandemia COVID-19 e con le recenti crisi climatiche. Il rischio, oggi, è globale, democratico (colpisce anche chi lo produce) o ancora distribuito in modo diseguale?»

**Traccia 3 (Tipologia C)**: «Il sistema IT-alert, sperimentato in Italia nel 2023, è stato il primo caso di allerta diretta ai cellulari della popolazione. Dopo aver descritto funzionamento e base giuridica del sistema, rifletti sul rapporto tra tecnologia e cultura della sicurezza: gli strumenti tecnologici possono sostituire la preparazione individuale, o la presuppongono?»

**Traccia 4 (Tipologia B)**: Testo di partenza: art. 2 del D.Lgs. 1/2018 (attività della protezione civile). «Il sistema italiano distingue quattro attività: **previsione, prevenzione e mitigazione, gestione delle emergenze, superamento dell'emergenza** (l'attività un tempo detta "soccorso" è oggi "gestione delle emergenze"). Analizza come questi quattro momenti si integrano in un caso a tua scelta (Amatrice 2016, Ischia 2022, Vaia 2018, alluvione Emilia-Romagna 2023). Quali sono le criticità strutturali emerse?»

**Traccia 5 (Tipologia C)**: «Il volontariato di protezione civile in Italia coinvolge oltre 300.000 persone. È un fenomeno peculiare italiano, radicato nell'art. 118 ultimo comma della Costituzione (principio di sussidiarietà orizzontale). Analizza il ruolo del volontariato nella tua comunità e discuti se oggi possa essere considerato una "forma evoluta di cittadinanza".»

### Template per prodotti PCTO — 5 formati concreti

Ogni template include: obiettivi, competenze attese, durata, struttura del prodotto, criteri di valutazione.

**Template A — Podcast istituzionale "Sicuri Insieme"**
- *Prodotto*: serie di 6 episodi di 12-15 minuti ciascuno.
- *Ruoli*: regia, conduzione, ricerca, editing audio, cura del sito di pubblicazione.
- *Competenze*: comunicazione digitale, public speaking, fact-checking, gestione del tempo.
- *Durata*: 40-50 ore PCTO.
- *Valutazione*: correttezza scientifica (pesi 40%), qualità comunicativa (30%), rispetto scadenze (15%), lavoro di squadra (15%).
- *Output pubblicabile*: Spreaker free, canale YouTube con link sul sito del Gruppo.

**Template B — Campagna social "Io sono pronto"**
- *Prodotto*: 15 post Instagram + 5 reel di 60 secondi + 1 evento di lancio.
- *Temi*: zaino d'emergenza, piano familiare, 112, IT-alert, aree di attesa.
- *Durata*: 30 ore PCTO.
- *Valutazione*: reach e engagement reali, correttezza informativa, estetica coerente con il design istituzionale PA.
- *Output*: profili social della scuola e del Gruppo.

**Template C — Ricerca "Il rischio nel mio quartiere"**
- *Prodotto*: dossier di 40-60 pagine con cartografia.
- *Metodo*: analisi mappe PAI, intervista a volontari e tecnici comunali, sopralluoghi fotografici, confronto con dati storici.
- *Durata*: 60 ore PCTO distribuite su 3 mesi.
- *Output*: pubblicazione sul sito del Gruppo, consegna copia al Comune.

**Template D — Evento "Giornata della Prevenzione"**
- *Prodotto*: organizzazione completa di una giornata aperta alla cittadinanza.
- *Ruoli*: coordinamento, logistica, comunicazione, accoglienza, documentazione.
- *Durata*: 30 ore di preparazione + 8 ore l'evento.
- *Valutazione*: partecipazione effettiva, feedback visitatori (questionario), rendicontazione finale.

**Template E — Documentario video "Volti della protezione"**
- *Prodotto*: documentario di 20-25 minuti con 6-8 interviste a figure della comunità (volontario anziano, volontario giovane, sindaco, insegnante che ha vissuto un'emergenza, geologo, comandante VVF locale).
- *Competenze*: regia, intervista, montaggio, narrazione.
- *Durata*: 50 ore PCTO.
- *Output*: proiezione pubblica + pubblicazione online.

### Dibattito strutturato — 6 argomenti pronti

Formato debate (regole parlamentari, squadra pro e contro, tempi rigorosi). Durata tipica: 90 minuti con preparazione di 2-3 ore.

1. **"L'autoprotezione dovrebbe essere una materia obbligatoria già dalla scuola primaria"** — pro: cittadinanza responsabile; contro: rischio di ansia in bambini piccoli.
2. **"Le zone classificate a rischio PAI elevato dovrebbero essere evacuate permanentemente"** — pro: tutela vite umane; contro: diritto alla casa, costi sociali.
3. **"Il social media è un utile alleato della protezione civile o un moltiplicatore di disinformazione?"** — bilanciamento evidenze.
4. **"Il volontariato dovrebbe ricevere compensi economici per i servizi prestati?"** — impatto sulla natura sussidiaria dell'istituto.
5. **"L'IT-alert crea un falso senso di sicurezza tecnologica?"** — tecno-ottimismo vs tecno-scetticismo.
6. **"Le compagnie di assicurazione sulle case dovrebbero essere obbligatorie in aree a rischio?"** — art. 42 Cost. e interesse pubblico.

### Compiti di realtà — 4 progetti classe

**Progetto Alpha — Audit del Piano di Evacuazione della scuola**
La classe, formata da un tecnico esterno (RSPP o volontario esperto), realizza un audit del Piano di Evacuazione della propria scuola. Output: report tecnico di 20-30 pagine con analisi criticità e 10 raccomandazioni operative, presentato al Dirigente Scolastico in una seduta formale. Valutazione: documentabilità delle osservazioni, fattibilità delle raccomandazioni, qualità della presentazione.

**Progetto Beta — Dashboard dei rischi territoriali**
Realizzazione di una dashboard web interattiva (HTML/JS/Leaflet) che aggrega i dati pubblici su Genzano: zone sismiche, PAI, incendi storici, aree di attesa. Deve essere pubblicata con licenza aperta. Richiede competenze informatiche avanzate (adatto a istituti tecnici). Valutazione: qualità del codice, accessibilità WCAG, accuratezza dati, usabilità.

**Progetto Gamma — Indagine sulla percezione del rischio**
Progettazione e conduzione di un'indagine sociologica sulla percezione del rischio tra i cittadini di Genzano (campione di almeno 200 persone). Include costruzione del questionario, somministrazione sul campo, analisi statistica con strumenti open source (R, Python), restituzione pubblica dei risultati. Collaborazione con università. Valutazione: rigore metodologico, qualità dell'analisi.

**Progetto Delta — Manuale operativo della classe per emergenze sismiche**
Redazione di un manuale di 15-20 pagine specifico per la propria classe: chi fa cosa in caso di terremoto, come si gestiscono alunni con BES/DSA/disabilità durante evacuazione, chi tiene il registro, chi comunica con le famiglie. Approvato da Dirigente + RSPP + docenti della classe. Diventa allegato al Piano di Emergenza d'istituto.

### Esempi di interviste per PCTO — 3 profili da intervistare

**Profilo 1 — Volontario storico del Gruppo (40+ anni di attività)**
Domande-chiave:
- Come è cambiato il volontariato dagli anni '80 ad oggi?
- Quali sono i 3 eventi che ti hanno segnato di più?
- Cosa diresti a un sedicenne che oggi si chiede se impegnarsi per la comunità?

**Profilo 2 — Sindaco o Assessore con delega alla PC**
Domande-chiave:
- Come si finanzia il sistema comunale di protezione civile?
- Cosa è il COC e quando si attiva?
- Quale è la pianificazione in caso di scenario di riferimento (es. terremoto M 6.0 ai Castelli)?

**Profilo 3 — Ricercatore scientifico (geologo / sismologo / meteorologo)**
Domande-chiave:
- Come funziona la previsione probabilistica dei terremoti? Perché non si può fare quella deterministica?
- Quanto è affidabile un bollettino di allerta meteo?
- Cosa ci dicono i modelli climatici per i Castelli nei prossimi 20 anni?

---

## Laboratori di comunicazione e collaborazione

Attività stampabili con spazi per le risposte e guida per il docente nella pagina successiva. Scegliere la fascia indicata nella singola scheda e adattare tempi e strumenti alla classe. Le schede sono incluse anche nei pacchetti da stampare e da scaricare.

- [Il costo delle scelte](/formazione/schede-stampabili/il-costo-delle-scelte-secondaria2/) — 14–19 anni. Confrontare alternative esplicitando le ipotesi.
- [Due archivi, una sola versione](/formazione/schede-stampabili/due-archivi-una-sola-versione-secondaria2/) — 14–19 anni. Progettare un controllo fra formati didattici.
- [Il sensore non dice tutta la verità](/formazione/schede-stampabili/il-sensore-non-dice-tutta-la-verita-secondaria2/) — 15–19 anni. Quantificare falsi allarmi e mancate rilevazioni.
- [Una catena di dipendenze](/formazione/schede-stampabili/una-catena-di-dipendenze-secondaria2/) — 14–19 anni. Individuare punti comuni di guasto.
- [Dal test alla correzione](/formazione/schede-stampabili/dal-test-alla-correzione-secondaria2/) — 15–19 anni. Valutare un materiale tramite prove osservabili.

## Oggetti sconosciuti e confezioni alterate

Percorso di educazione alla sicurezza su una sola regola, ripetuta in forme adatte all'età: **non tocco, mi allontano, avviso un adulto**. Le attività si svolgono soltanto su carta e con dialoghi: nessuna ricerca o manipolazione di oggetti reali, nessuna chiamata di prova al 112. Ogni scheda ha la nota per l'adulto e la soluzione capovolta. Leggete prima la guida per gli adulti. Le schede sono incluse nei pacchetti da stampare e da scaricare.

- [A chi chiedere aiuto](/formazione/schede-stampabili/oggetti-a-chi-chiedere-aiuto-secondaria2/) — 14–19 anni. Distinguere una segnalazione ordinaria da una richiesta urgente di soccorso.
- [Una notizia che fa paura](/formazione/schede-stampabili/oggetti-una-notizia-che-fa-paura-secondaria2/) — 14–19 anni. Verificare un messaggio allarmistico senza amplificarlo.
- [Pulire il parco in sicurezza](/formazione/schede-stampabili/oggetti-pulire-il-parco-in-sicurezza-secondaria2/) — 14–19 anni. Riconoscere i limiti di una raccolta rifiuti organizzata.
- [Se non so che cosa è](/formazione/schede-stampabili/oggetti-se-non-so-che-cosa-e-facilitata/) — versione facilitata, età diverse. Chiedere aiuto attraverso il proprio modo di comunicare.
- [Una bevanda trovata](/formazione/schede-stampabili/oggetti-una-bevanda-trovata-facilitata/) — versione facilitata, età diverse. Lasciare una bevanda sconosciuta e chiedere aiuto.
- [Il patto con gli adulti](/formazione/schede-stampabili/oggetti-il-patto-con-gli-adulti-famiglia/) — per famiglie, scuola e accompagnatori. Concordare un aiuto concreto e accogliere le segnalazioni.
- [Guida per gli adulti](/formazione/schede-stampabili/oggetti-sconosciuti-guida-adulti/) — come proporre il percorso, adattamenti, cosa fare se il ritrovamento è reale, risposte e fonti.


## Natura che non si tocca

Percorso di educazione alla sicurezza all'aperto su una sola regola, ripetuta in forme adatte all'età: **guardo, non tocco, chiedo a un adulto**. Bacche e funghi, bruchi della processionaria, vespe, zecche, cani sconosciuti, serpenti. Le attività si svolgono soltanto su carta e con dialoghi, senza contatto con animali o piante reali. Ogni scheda ha la nota per l'adulto e la soluzione capovolta. Leggete prima la guida per gli adulti. Le schede sono incluse nei pacchetti da stampare e da scaricare.

- [A chi chiedere aiuto](/formazione/schede-stampabili/natura-a-chi-chiedere-aiuto-secondaria2/) — 14–19 anni. Distinguere una segnalazione ordinaria da una richiesta urgente di soccorso.
- [Rimedi che circolano](/formazione/schede-stampabili/natura-rimedi-che-circolano-secondaria2/) — 14–19 anni. Verificare i rimedi «sentiti dire» e rispondere in modo utile in una chat.
- [Uscita nel Parco: il piano del gruppo](/formazione/schede-stampabili/natura-uscita-nel-parco-il-piano-del-gruppo-secondaria2/) — 14–19 anni. Completare il piano di sicurezza di un’escursione, prima, durante e dopo.
- [Guardo, non tocco](/formazione/schede-stampabili/natura-guardo-non-tocco-facilitata/) — versione facilitata, età diverse. Chiedere aiuto davanti a una pianta o a un animale sconosciuto.
- [Un insetto vola vicino](/formazione/schede-stampabili/natura-un-insetto-vola-vicino-facilitata/) — versione facilitata, età diverse. Restare calmi con un insetto vicino e segnalare subito una puntura.
- [Il patto per le uscite](/formazione/schede-stampabili/natura-il-patto-per-le-uscite-famiglia/) — per famiglie, scuola e accompagnatori. Concordare un aiuto concreto per parco, giardino e gite.
- [Guida per gli adulti](/formazione/schede-stampabili/natura-che-non-si-tocca-guida-adulti/) — come proporre il percorso, adattamenti, cosa fare se succede davvero, risposte e fonti.

## Casa sicura

Percorso di educazione alla sicurezza domestica su una sola regola, ripetuta in forme adatte all'età: **non apro, non tocco, chiedo a un adulto**. Farmaci e prodotti per la casa, pile e magneti, cose calde, elettricità, principio di incendio in cucina, finestre e balconi. Le attività si svolgono soltanto su carta e con dialoghi, senza prove con prodotti o apparecchi reali. Ogni scheda ha la nota per l'adulto e la soluzione capovolta. Leggete prima la guida per gli adulti. Le schede sono incluse nei pacchetti da stampare e da scaricare.

- [A chi chiedere aiuto](/formazione/schede-stampabili/casa-a-chi-chiedere-aiuto-secondaria2/) — 14–19 anni. Distinguere una segnalazione ordinaria da una richiesta urgente di soccorso.
- [Miti in casa](/formazione/schede-stampabili/casa-miti-in-casa-secondaria2/) — 14–19 anni. Verificare i rimedi «sentiti dire» e rispondere in modo utile in una chat.
- [Io e i più piccoli](/formazione/schede-stampabili/casa-io-e-i-piu-piccoli-secondaria2/) — 14–19 anni. Preparare la casa quando si resta con fratelli o cugini piccoli.
- [Non apro, chiedo](/formazione/schede-stampabili/casa-non-apro-chiedo-facilitata/) — versione facilitata, età diverse. Chiedere aiuto davanti a una bottiglia o a una scatola sconosciuta.
- [Caldo: non tocco](/formazione/schede-stampabili/casa-caldo-non-tocco-facilitata/) — versione facilitata, età diverse. Stare lontani dalle cose calde e chiamare un adulto dopo una scottatura.
- [Il patto in casa](/formazione/schede-stampabili/casa-il-patto-in-casa-famiglia/) — per famiglie, scuola e accompagnatori. Concordare un aiuto concreto e organizzare la casa a misura di bambino.
- [Guida per gli adulti](/formazione/schede-stampabili/casa-sicura-guida-adulti/) — come proporre il percorso, adattamenti, cosa fare se succede davvero, risposte e fonti.

## Materiale di approfondimento

- [D.Lgs. 1/2018 — Codice della Protezione Civile](https://www.normattiva.it/) — Testo integrale su Normattiva
- [Dipartimento della Protezione Civile](https://www.protezionecivile.gov.it/it/) — Documentazione ufficiale
- [IdroGEO — ISPRA](https://idrogeo.isprambiente.it/) — Mappa del dissesto idrogeologico
- [INGV Terremoti](https://terremoti.ingv.it/) — Dati sismici in tempo reale
- [Io non rischio](https://www.iononrischio.it/) — Materiali della campagna nazionale
- [Aree di emergenza di Genzano](/cartografia/) — Mappa delle aree di attesa e accoglienza
- [Piano di Emergenza Comunale](/piano-emergenza/) — Struttura del piano
- [Piano di Emergenza Familiare](/piano-familiare/) — Modello compilabile
- [Giochi della Sicurezza — Ragazzi](/giochi/ragazzi/) — giochi per la fascia 11-14 (ok anche primo biennio)
- [Stop Disasters! — Simulatore ONU UNDRR](https://www.stopdisastersgame.org/game/) — Simulazione gratuita in italiano: 5 scenari (terremoto, alluvione, tsunami, uragano, incendio) con budget limitato. Ottimo come attività introduttiva al **Progetto C** (campagna di comunicazione del rischio) o come riflessione sul rapporto fra prevenzione strutturale e non strutturale.
- [Chi siamo](/chi-siamo/) — Il Gruppo Comunale di Genzano
- [Diventa Volontario](/diventa-volontario/) — Informazioni sull'iscrizione
- [Rapporti IPCC](https://www.ipcc.ch/) — Panel intergovernativo sui cambiamenti climatici
- [Copernicus Climate Change Service](https://climate.copernicus.eu/) — Dati climatici europei

### Fonti normative e curricolari

- [Legge 20 agosto 2019 n. 92](https://www.normattiva.it/) — Introduzione dell'insegnamento dell'educazione civica (art. 3 lett. h *protezione civile*; lett. h-ter *sicurezza nei luoghi di lavoro* introdotta dalla L. 21/2025)
- **D.M. 7 settembre 2024 n. 183 (Linee Guida nazionali per l'Educazione Civica, applicabili a decorrere dall'anno scolastico 2024/2025)** — Linee guida per l'insegnamento dell'educazione civica
- **Legge 17 febbraio 2025, n. 21** — Conoscenze di base in materia di sicurezza nei luoghi di lavoro nell'Educazione Civica (in vigore dal 19 marzo 2025)
- **D.P.R. 89/2010** — Regolamento dei Licei; **D.P.R. 87-88/2010** — Istituti Tecnici e Professionali
- **D.Lgs. 15 aprile 2005 n. 77** — Alternanza scuola-lavoro (oggi PCTO)
- **D.Lgs. 13 aprile 2017 n. 62** — Valutazione e certificazione competenze
- **Raccomandazione UE 2018/C 189/01** — 8 competenze chiave per l'apprendimento permanente
- [D.Lgs. 2 gennaio 2018 n. 1](/normativa/testo-unico-protezione-civile/) — Codice della Protezione Civile
- **D.Lgs. 3 luglio 2017 n. 117** — Codice del Terzo Settore
- **D.Lgs. 9 aprile 2008, n. 81** — Testo Unico sulla salute e sicurezza nei luoghi di lavoro
- **D.M. 26/08/1992** — Norme di prevenzione incendi per l'edilizia scolastica

### Bibliografia minima per il docente

- Ulrich Beck, *La società del rischio* (1986, trad. it. Carocci)
- Hans Jonas, *Il principio responsabilità* (1979, trad. it. Einaudi)
- Erri De Luca e altri, *Le parole della protezione civile* (DPC, disponibile online)
- Carlo Meletti et al., *Terremoti e pericolosità sismica in Italia* (INGV)
- IPCC, *AR6 — Sixth Assessment Report* (2021-2023) — sintesi per decisori

---

## Vuoi organizzare un incontro o un PCTO?

I volontari del Gruppo sono disponibili per interventi nelle scuole, visite alla sede operativa e percorsi PCTO strutturati. Possiamo costruire insieme un programma su misura per la vostra classe.

Scrivi a [segreteria@protezionecivilegenzano.it](mailto:segreteria@protezionecivilegenzano.it) per informazioni e prenotazioni.
