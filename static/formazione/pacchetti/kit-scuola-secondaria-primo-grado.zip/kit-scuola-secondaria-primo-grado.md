---
title: "Kit Didattico — Scuola Secondaria di Primo Grado"
description: "Materiale didattico di protezione civile per studenti dagli 11 ai 14 anni: rischi del territorio, sistema di allertamento, piano di emergenza e autoprotezione."
layout: "single"
toc: true
risorse_tema: "kit-emergenza"
---

Questo kit è pensato per i docenti della **scuola secondaria di primo grado** che vogliono approfondire con i propri studenti i temi della protezione civile, della conoscenza del rischio e della cittadinanza attiva.

I contenuti sono stati sviluppati dal Gruppo Comunale Volontari di Protezione Civile di Genzano di Roma e si prestano all'uso nelle ore di scienze, geografia, educazione civica e tecnologia.

> 📦 **Scarica il pacchetto offline** — [`kit-scuola-secondaria-primo-grado.zip`](/formazione/pacchetti/kit-scuola-secondaria-primo-grado.zip) (~229 KB) contiene tutte le schede stampabili linkate da questo kit, indice cliccabile, istruzioni per l'uso. Aggiornato automaticamente quando aggiungiamo, modifichiamo o togliamo schede dal kit.

---

## Guida per il docente

### Riferimenti normativi e curricolari

Il percorso si inserisce pienamente nelle **33 ore annuali di Educazione Civica** previste dalla **Legge 20 agosto 2019 n. 92** (art. 1, 2 e 3) e dalle **Linee guida per l'insegnamento dell'educazione civica** (D.M. 7 settembre 2024 n. 183, **applicabili a decorrere dall'anno scolastico 2024/2025**), che individuano nella **sicurezza stradale, salute e benessere, Agenda 2030, cittadinanza digitale, conoscenza del territorio** i nuclei tematici da sviluppare.

Il percorso risponde inoltre alle **Indicazioni Nazionali per il Curricolo della Scuola Secondaria di Primo Grado** (2012) e ai **Nuovi Scenari** (2018), in particolare ai traguardi delle discipline Scienze, Geografia, Tecnologia e al profilo di cittadinanza di fine primo ciclo.

Il riferimento normativo che lega la scuola al Sistema nazionale di Protezione Civile è l'**articolo 3, lettera h) della Legge 92/2019**, che include esplicitamente la *"formazione di base in materia di protezione civile"* tra i temi dell'Educazione Civica. Il **D.Lgs. 1/2018** (Codice della Protezione Civile) costituisce la cornice generale che descrive attività, organizzazione, pianificazione e ruolo del Servizio nazionale.

La **Legge 17 febbraio 2025, n. 21** ha introdotto la **lettera h-ter)** all'art. 3 della L. 92/2019, aggiungendo le *"conoscenze di base in materia di sicurezza nei luoghi di lavoro"* tra i temi dell'Educazione Civica: sebbene il fuoco principale sia sulla Secondaria di II grado, è opportuno introdurre già in Secondaria di I grado i concetti di base (DPI, segnaletica, comportamenti sicuri) come ponte verso il triennio.

> 📚 **Per i docenti — risorse coordinate**
>
> - **Pagina hub** [La Protezione Civile per l'Educazione Civica](/formazione/educazione-civica/) — mappatura completa dei nostri contenuti sui **3 Nuclei Concettuali del D.M. 183/2024** (Costituzione, Sostenibilità, Cittadinanza Digitale) + **Goal Agenda 2030 ONU** + tabella interdisciplinare + calendario delle 33 ore.
> - **Rubrica valutativa** pronta per la fascia: [Rubrica Ed. Civica — Secondaria di primo grado](/formazione/schede-stampabili/rubrica-valutativa-secondaria/) — indicatori × livelli, con esempi di giudizio descrittivo / motivazione del voto.


### Obiettivi di apprendimento formalizzati

**Conoscenze**
- Conosce la struttura del Servizio Nazionale di Protezione Civile e il principio di sussidiarietà
- Conosce i principali rischi del territorio italiano e dei Castelli Romani
- Conosce il sistema di allertamento e i codici colore
- Conosce il D.Lgs. 1/2018 nelle sue linee essenziali
- Conosce il sistema IT-alert e i canali ufficiali di informazione

**Abilità**
- Legge e interpreta un bollettino di allerta meteo regionale
- Consulta in autonomia i portali ufficiali (Regione Lazio, DPC, INGV, ISPRA)
- Redige un Piano di Emergenza Familiare completo
- Identifica sulla cartografia le aree di attesa e gli elementi di rischio
- Produce un messaggio di comunicazione del rischio corretto e non allarmistico

**Competenze chiave europee (Raccomandazione UE 2018/C 189/01)**
- **Competenza alfabetica funzionale**: legge, produce e valuta testi informativi e istruzioni operative
- **Competenza matematica + base in scienze e tecnologia**: utilizza dati numerici (magnitudo, mm di pioggia, livelli di allerta) e comprende fenomeni naturali
- **Competenza digitale**: distingue fonti affidabili da notizie false, usa correttamente strumenti di monitoraggio online
- **Competenza personale, sociale e imparare a imparare**: gestisce l'incertezza, pianifica comportamenti di autoprotezione
- **Competenza in materia di cittadinanza**: comprende il ruolo delle istituzioni e del volontariato, esercita responsabilità civica

**Obiettivi di educazione alla cittadinanza (traguardi fine primo ciclo)**
- Riconosce e rispetta i principi costituzionali sulla protezione della persona (art. 32, 117, 118)
- Comprende il valore del volontariato come esercizio di sussidiarietà orizzontale
- Valuta criticamente l'informazione ricevuta attraverso i media

### Collegamento con le discipline

| Disciplina | Argomenti collegati | Traguardi di competenza coinvolti |
|---|---|---|
| **Scienze** | Terremoti, vulcani, ciclo dell'acqua, meteorologia, geologia | Conosce i principali fenomeni geologici; riconosce gli effetti delle attività umane sull'ambiente |
| **Geografia** | Territorio, carte tematiche, rischio idrogeologico, cambiamenti climatici | Legge e interpreta vari tipi di carte geografiche; osserva e descrive sistemi territoriali |
| **Ed. civica** | Cittadinanza attiva, volontariato, istituzioni, diritti e doveri | Agenda 2030 obiettivi 11 e 13; conoscenza Costituzione |
| **Tecnologia** | Sistemi di allertamento, app di emergenza, strumenti di monitoraggio | Uso consapevole delle tecnologie della comunicazione |
| **Italiano** | Comunicazione del rischio, analisi di testi informativi istituzionali | Produce testi informativi e argomentativi; distingue fonti |
| **Arte e immagine** | Infografiche, cartelli di emergenza, simbologia istituzionale | Progetta elaborati visivi efficaci |
| **Storia** | Grandi eventi (Messina 1908, Vajont 1963, Irpinia 1980, Emilia 2012) | Comprende la relazione tra evento e risposta istituzionale |

### Durata consigliata e tabella del percorso

Il percorso completo si articola in **Moduli da 60 minuti**, adattabili in base alle esigenze della classe. Ogni modulo è autonomo.

| Modulo | Tema | Durata | Discipline coinvolte |
|---|---|---|---|
| 1 | Sistema Nazionale di Protezione Civile | 60' | Ed. civica, Storia |
| 2 | Rischi del territorio | 60' | Geografia, Scienze |
| 3 | Sistema di allertamento | 60' | Tecnologia, Italiano |
| 4 | Comportamenti di autoprotezione | 60' | Ed. civica, Ed. fisica |
| 5 | Piano di emergenza familiare | 60' + casa | Ed. civica, Tecnologia |
| 6 | Cittadinanza attiva e volontariato | 60' | Ed. civica, Italiano |

**Attività di approfondimento** (UdA interdisciplinare, Compito di realtà): +4-6 ore

**Totale complessivo stimato**: 10-12 ore, distribuibili sulle 33 ore annuali di Educazione Civica o ripartite tra diverse discipline.

### Prerequisiti

- Capacità di lettura di testi informativi di livello B1 (CEFR)
- Conoscenze di base di geografia fisica dell'Italia
- Uso autonomo di un browser e di un motore di ricerca
- Aver svolto almeno una prova di evacuazione scolastica

### Metodologie didattiche suggerite

- **Flipped classroom**: per il Modulo 1 (studio autonomo del D.Lgs. 1/2018 in versione semplificata a casa + discussione in classe)
- **Cooperative learning**: Modulo 2 (gruppi che studiano un rischio specifico e lo presentano alla classe)
- **Problem-based learning**: Modulo 4 (scenari di emergenza da gestire in gruppo)
- **Debate**: Modulo 6 (cittadinanza e responsabilità)
- **Service learning**: attività di sensibilizzazione a cura della classe nel territorio o nella scuola stessa

---

## Modulo 1 — Il Sistema Nazionale di Protezione Civile

### Il principio di sussidiarietà

Il sistema italiano di protezione civile si basa sul **principio di sussidiarietà**: la prima risposta all'emergenza parte dal livello più vicino al cittadino.

**Livelli di intervento:**

| Livello | Chi interviene | Quando |
|---|---|---|
| **Comunale** | Sindaco, COC, volontari locali | Emergenze gestibili con risorse locali |
| **Provinciale / Regionale** | Prefetto, Regione, colonna mobile regionale | Emergenze che superano le capacità del comune |
| **Nazionale** | Dipartimento PC, Consiglio dei Ministri | Emergenze di rilievo nazionale (stato di emergenza) |

Il **Sindaco** è la prima autorità di protezione civile nel comune. In caso di emergenza attiva il **Centro Operativo Comunale (COC)** e coordina i primi interventi.

### Le attività della Protezione Civile

La protezione civile non si occupa solo di emergenze. Le sue attività si dividono in quattro fasi:

1. **Previsione** — studiare i rischi del territorio, analizzare i dati, fare scenari
2. **Prevenzione** — ridurre i rischi prima che si verifichino (piani, opere, informazione)
3. **Gestione dell'emergenza** — soccorso, assistenza, coordinamento durante l'evento
4. **Superamento dell'emergenza** — ripristino delle condizioni normali, ricostruzione

### Il Codice della Protezione Civile

Il sistema è regolato dal **Decreto Legislativo 1/2018** (Codice della Protezione Civile), che definisce:
- Le competenze di Stato, Regioni, Province e Comuni
- Le tipologie di eventi emergenziali (a, b, c)
- Il ruolo del volontariato come componente fondamentale del sistema
- I diritti e i doveri dei cittadini in emergenza

### Attività: intervista al volontario

Se possibile, invitate un volontario del Gruppo in classe. Gli studenti preparano domande su:
- Perché ha scelto di fare il volontario
- Quali emergenze ha affrontato
- Come si svolge un'attivazione
- Che formazione ha ricevuto

---

## Modulo 2 — I rischi del territorio

### Il contesto geologico

Genzano di Roma sorge sui **Colli Albani**, un complesso vulcanico quiescente situato a sud-est di Roma. Il territorio è caratterizzato da:
- **Origine vulcanica**: il substrato è formato da tufi e lave dei Colli Albani
- **Morfologia collinare**: pendii che in caso di piogge intense possono generare fenomeni di erosione e frane
- **Presenza del lago di Nemi**: bacino di origine vulcanica nelle vicinanze
- **Vegetazione**: boschi e macchia mediterranea del Parco Regionale dei Castelli Romani

### Mappa dei rischi

| Rischio | Livello per Genzano di Roma | Descrizione |
|---|---|---|
| **Sismico** | Medio | Zona sismica 2B — possibili scosse avvertite dalla popolazione |
| **Idrogeologico** | Medio-alto in alcune zone | Fossi, impluvi e versanti collinari soggetti a frane e allagamenti localizzati |
| **Incendio boschivo** | Alto in estate | Vasta copertura boschiva, periodo critico giugno-settembre |
| **Meteorologico** | Variabile | Temporali intensi, grandinate, vento forte, ondate di calore |
| **Vulcanico** | Basso (monitorato) | Colli Albani quiescenti, monitoraggio continuo dell'INGV |

### Attività: analisi del Piano di Protezione Civile

Il Comune di Genzano ha un Piano di Protezione Civile che definisce:
- Le aree a rischio
- Le aree di attesa (dove radunarsi)
- Le aree di accoglienza (dove alloggiare temporaneamente)
- Le vie di fuga

Consultate la [mappa delle aree di emergenza](/cartografia/) del nostro sito e identificate:
1. L'area di attesa più vicina alla scuola
2. L'area di attesa più vicina a casa vostra
3. Il percorso più sicuro per raggiungerle

---

## Modulo 3 — Il sistema di allertamento

### Come funziona l'allertamento in Italia

Il sistema di allertamento meteo-idrogeologico italiano è gestito dalla **rete dei Centri Funzionali** coordinati dal Dipartimento della Protezione Civile.

**La catena dell'allertamento:**
1. I modelli meteorologici prevedono un evento potenzialmente pericoloso
2. Il **Centro Funzionale Centrale** (DPC) emette il Bollettino di Vigilanza Meteorologica nazionale
3. Il **Centro Funzionale Regionale** del Lazio valuta gli effetti sul territorio e emette l'allerta
4. La **Regione Lazio** comunica l'allerta ai Comuni
5. Il **Sindaco** attiva le procedure previste dal Piano e informa la popolazione
6. I **volontari** si attivano per monitorare il territorio e assistere la cittadinanza

### I codici colore

| Colore | Livello | Significato |
|---|---|---|
| **Verde** | Nessuna allerta | Assenza di fenomeni significativi prevedibili |
| **Giallo** | Ordinaria criticità | Fenomeni di intensità moderata, possibili disagi locali |
| **Arancione** | Moderata criticità | Fenomeni intensi, possibili danni e rischi per la sicurezza |
| **Rosso** | Elevata criticità | Fenomeni molto intensi e diffusi, rischio elevato per la popolazione |

**Importante**: l'allerta è sempre associata a uno o più **tipi di rischio** (idrogeologico, idraulico, temporali, vento, neve/ghiaccio, mare) e a una **zona di allerta** specifica. Un'allerta arancione per temporali non è la stessa cosa di un'allerta arancione per rischio idrogeologico.

### IT-alert

**IT-alert** è il sistema nazionale di allarme pubblico che invia messaggi direttamente sui telefoni cellulari in caso di gravi emergenze imminenti o in corso. Non richiede iscrizione e funziona anche senza connessione internet.

### Attività: decodifica il bollettino

Scaricate un bollettino di allerta reale dal sito dell'[Agenzia di Protezione Civile della Regione Lazio](https://protezionecivile.regione.lazio.it/) e compilate questa scheda:

| Domanda | Risposta |
|---|---|
| Data di emissione | |
| Periodo di validità | |
| Zone di allerta interessate | |
| Tipo di rischio | |
| Livello di allerta (colore) | |
| Fenomeni previsti | |
| Cosa dovresti fare? | |

---

## Modulo 4 — Comportamenti di autoprotezione

{{< pittogramma src="/pittogrammi/iso7010/punto-raccolta.svg" alt="Cartello del punto di raccolta" size="medium" >}}

### Terremoto

**Prima**: individua i punti più sicuri della casa (sotto tavoli robusti, vicino a muri portanti, lontano da finestre e mobili pesanti). Fissa scaffali e librerie al muro.

**Durante**:
- In edificio: riparati sotto un tavolo o nel vano di una porta portante. Non uscire durante la scossa, non usare l'ascensore
- All'aperto: allontanati da edifici, cornicioni, linee elettriche. Vai in uno spazio aperto
- In auto: accosta e resta in macchina lontano da ponti, cavalcavia e edifici

**Dopo**: esci con calma, raggiungi l'area di attesa, non rientrare finché le autorità non lo autorizzano. Verifica le condizioni dei vicini, specialmente persone anziane o con disabilità.

### Alluvione

**Prima**: informati se la tua zona è a rischio consultando il [Piano di Protezione Civile](/piano-emergenza/). Non ostruire tombini e canali con rifiuti.

**Durante**:
- Non scendere in cantine, garage o piani interrati
- Non attraversare strade o sottopassi allagati, né a piedi né in auto
- Se sei in auto e l'acqua sale, abbandona il veicolo
- Raggiungi i piani alti dell'edificio in cui ti trovi

**Dopo**: non bere acqua dal rubinetto finché non è dichiarata potabile. Non toccare impianti elettrici bagnati.

### Incendio boschivo

**Prima**: non accendere fuochi in aree naturali, non abbandonare rifiuti, non lanciare mozziconi.

**Durante**:
- Chiama immediatamente il 112: nel Lazio è l'unico numero di emergenza e attiva vigili del fuoco e forestali
- Allontanati in direzione opposta al vento, perpendicolarmente al fronte del fuoco
- Se il fumo è denso, copriti bocca e naso e stai basso
- Non rifugiarti in un veicolo

**Dopo**: segnala alle autorità eventuali focolai residui.

### Ondata di calore

- Evita di uscire nelle ore più calde (11-17)
- Bevi molta acqua anche se non hai sete
- Fai attenzione a bambini, anziani e persone con malattie croniche
- Non lasciare mai persone o animali in auto al sole

### Attività: scenari di emergenza

Dividete la classe in gruppi. Ogni gruppo riceve uno scenario e deve:
1. Identificare il tipo di rischio
2. Decidere i comportamenti corretti
3. Indicare chi chiamare
4. Presentare la risposta alla classe

**Scenario A**: *"Sei a casa al primo piano, piove fortissimo da ore, l'acqua ha cominciato a entrare dal portone del palazzo."*

**Scenario B**: *"Sei a scuola, durante la lezione senti il pavimento tremare per circa 15 secondi."*

**Scenario C**: *"Stai passeggiando nel bosco vicino a Genzano e vedi del fumo denso salire dagli alberi a circa 200 metri da te."*

**Scenario D**: *"È agosto, ci sono 40 gradi, il tuo vicino di casa anziano non risponde al citofono da ieri."*

---

## Modulo 5 — Il piano di emergenza familiare

### Perché serve un piano familiare

In un'emergenza le reti telefoniche possono essere sovraccariche, le strade bloccate e i membri della famiglia in posti diversi. Avere un piano concordato prima permette a tutti di sapere cosa fare senza dover comunicare nel momento critico.

### Elementi del piano

**1. Conoscenza dei rischi**
- Quali rischi interessano la zona in cui vivo?
- La mia casa è in un'area sicura o a rischio?

**2. Punti di incontro**
- Punto di incontro vicino a casa (es. piazza, parcheggio)
- Punto di incontro alternativo fuori zona
- [Aree di attesa ufficiali](/cartografia/) del Comune di Genzano

**3. Contatto fuori zona**
- Una persona che vive in un'altra città che tutti i familiari possono chiamare per scambiarsi notizie

**4. Numeri utili**

Nel Lazio, dal 2017, **l'unico numero di emergenza per il cittadino è il 112** (NUE). Tutte le chiamate arrivano alla Centrale Unica che smista l'intervento all'ente competente.

| Numero | Servizio |
|---|---|
| 112 | Numero Unico Emergenze (NUE) — qualsiasi emergenza |
| 803&nbsp;555 | Sala Operativa Protezione Civile Lazio — non urgenze |

**5. Kit di emergenza**
- Acqua (almeno 2 litri a persona)
- Torcia con batterie di riserva
- Radio a batterie o a manovella
- Kit di primo soccorso
- Medicinali personali
- Copie dei documenti
- Caricatore portatile per telefono
- Coperta termica
- Cambio di vestiti e scarpe chiuse
- Alimenti a lunga conservazione

### Attività: compila il tuo piano familiare

Ogni studente porta a casa la scheda e la compila con la famiglia. Il [Piano di Emergenza Familiare](/piano-familiare/) del Gruppo è scaricabile e stampabile.

Nella lezione successiva, confrontate i piani in classe (senza condividere dati personali): quali punti di incontro avete scelto? Qualcuno ha individuato criticità?

---

## Modulo 6 — Cittadinanza attiva e volontariato

{{< pittogramma src="/pittogrammi/arasaac/volontario.png" alt="Pittogramma: volontario di protezione civile" size="medium" >}}

### Il volontariato di protezione civile

In Italia operano oltre **300.000 volontari** di protezione civile, organizzati in migliaia di associazioni. Sono cittadini che dedicano il proprio tempo libero alla sicurezza della comunità.

**Cosa fanno i volontari:**
- Monitorano il territorio durante le allerte
- Assistono la popolazione durante le emergenze
- Distribuiscono materiali (acqua, coperte, pasti)
- Montano e gestiscono i campi di accoglienza
- Partecipano alle ricerche di persone disperse
- Fanno prevenzione e informazione nelle scuole e sul territorio
- Operano nella lotta attiva agli incendi boschivi

**Chi può diventare volontario:**
- Maggiorenni (in molte associazioni si può iniziare dai 16 anni con il consenso dei genitori)
- Non servono competenze specifiche: la formazione viene fornita dall'organizzazione
- Serve solo la voglia di mettersi al servizio degli altri

### Il Gruppo di Genzano

Il Gruppo Comunale Volontari di Protezione Civile di Genzano di Roma è composto da cittadini volontari che operano sul territorio dei Castelli Romani. I settori operativi comprendono: antincendio boschivo, telecomunicazioni, logistica, divulgazione nelle scuole e pilotaggio droni.

Per saperne di più: [Chi siamo](/chi-siamo/) | [Diventa Volontario](/diventa-volontario/)

### Attività: progetto di prevenzione

**Lavoro di gruppo**: progettate una campagna di comunicazione sul rischio per il vostro quartiere o la vostra scuola. Ogni gruppo deve:

1. Scegliere un rischio specifico
2. Identificare il pubblico (bambini, anziani, famiglie)
3. Creare un messaggio chiaro e non allarmistico
4. Scegliere il formato (volantino, video, post per i social, manifesto)
5. Presentare il progetto alla classe

**Criteri di valutazione:**
- Correttezza scientifica delle informazioni
- Chiarezza del messaggio
- Adeguatezza al pubblico scelto
- Creatività nella comunicazione

---

## Quiz di verifica

**1. Qual è il principio su cui si basa il sistema di protezione civile italiano?**
- a) Centralizzazione
- b) Sussidiarietà ✔
- c) Autonomia regionale

**2. Quali sono le attività della protezione civile?**
- a) Allarme, soccorso, evacuazione, ricostruzione
- b) Previsione, prevenzione, gestione dell'emergenza, superamento dell'emergenza ✔
- c) Monitoraggio, allerta, intervento, ripristino

**3. In quale zona sismica si trova Genzano di Roma?**
- a) Zona 1 (alta sismicità)
- b) Zona 2B (media sismicità) ✔
- c) Zona 4 (bassa sismicità)

**4. Cosa significa un'allerta arancione?**
- a) Nessun pericolo
- b) Criticità moderata con fenomeni intensi ✔
- c) Situazione estrema, evacuazione immediata

**5. Durante un'alluvione, dove NON devi andare?**
- a) Ai piani alti
- b) In cantina o nei piani interrati ✔
- c) Sul terrazzo

**6. Qual è la prima autorità di protezione civile nel comune?**
- a) Il prefetto
- b) Il presidente della Regione
- c) Il sindaco ✔

**7. Cosa deve contenere un piano di emergenza familiare?**
- a) Solo i numeri di emergenza
- b) Punto di incontro, contatto fuori zona, kit di emergenza, numeri utili ✔
- c) Solo la mappa della città

**8. Da che età si può diventare volontari di protezione civile?**
- a) Solo dai 18 anni
- b) Dai 16 anni con il consenso dei genitori ✔
- c) Solo dai 21 anni

**9. Quale numero chiami se vedi un incendio boschivo?**
- a) La polizia locale
- b) Il 112, unico numero di emergenza nel Lazio ✔
- c) Nessuno, si spegne da solo

**10. Cos'è IT-alert?**
- a) Un'app da scaricare
- b) Un sistema che invia messaggi di emergenza direttamente sui telefoni ✔
- c) Un sito web di previsioni meteo

---

## Unità di Apprendimento interdisciplinare

Per chi vuole strutturare il percorso come UdA valutabile a livello istituzionale, ecco un modello pronto.

### UdA — *"Conoscere il rischio del mio territorio"*

**Titolo**: Conoscere il rischio del mio territorio — dalla mappa al piano familiare

**Destinatari**: classe terza di scuola secondaria di primo grado (14 anni)

**Periodo**: II quadrimestre, 6-8 settimane

**Discipline coinvolte**: Geografia, Scienze, Ed. civica, Italiano, Tecnologia

**Monte ore**: 12 ore in orario curricolare + 3 ore di studio autonomo

**Compito di realtà**: la classe produce una **Guida al rischio del quartiere di Genzano** destinata agli alunni di V primaria (pubblicata in formato PDF e distribuita alle scuole primarie del territorio, previo accordo del Dirigente).

**Fasi**

| Fase | Attività | Ore |
|---|---|---|
| 1. Avvio | Presentazione UdA, patto formativo, divisione in gruppi tematici | 2 |
| 2. Ricerca | Gruppi studiano rischi specifici su portali ufficiali (IdroGEO, INGV, DPC) | 3 |
| 3. Mappatura | Uscita sul territorio, georeferenziazione delle osservazioni | 2 |
| 4. Scrittura | Ogni gruppo redige una sezione della guida | 2 |
| 5. Editing | Redazione comune, peer review, correzione | 2 |
| 6. Consegna | Presentazione alla classe di V primaria, feedback, valutazione | 1 |

**Prodotti attesi**
- Guida al rischio del quartiere (15-20 pagine, formato PDF)
- Presentazione alla V primaria (30 minuti)
- Autovalutazione individuale (scheda riflessiva)

**Valutazione**: rubrica multidimensionale (vedi sotto) con pesi diversi per conoscenze, abilità e competenze civiche. Il voto confluisce nell'**Educazione Civica** (33 ore annuali) e può essere valorizzato come evidenza nella **certificazione delle competenze** di fine primo ciclo.

---

> 🔬 **Esperimenti e attività pratiche.** Approfondisci con gli [esperimenti di protezione civile](/formazione/esperimenti/). Per questa fascia funzionano bene la **viscosità del magma**, **città di asfalto contro città di prato**, la **diffusione di una nube** e **«quanto è lontano il temporale?»**.

## Schede fotocopiabili pronte per la stampa

<div class="alert alert-success" role="note">
<p class="mb-1"><i class="bi bi-printer-fill me-2" aria-hidden="true"></i><strong>Schede già pronte per la stampa</strong></p>
<p class="mb-0">Diverse schede sono già pronte: apri, premi <kbd>Stampa</kbd> del browser (Ctrl+P o Cmd+P) e ottieni un foglio A4 perfetto con intestazione istituzionale. Pensate per la scuola secondaria di primo grado.
👉 <strong><a href="/formazione/schede-stampabili/">Vai all'elenco delle schede stampabili</a></strong> (in continuo arricchimento).
Per richieste specifiche: <a href="mailto:segreteria@protezionecivilegenzano.it">segreteria@protezionecivilegenzano.it</a>.</p>
</div>

Schede pronte per la stampa specifiche per la scuola secondaria di primo grado:

- 👉 [**Decodifica del bollettino di allerta**](/formazione/schede-stampabili/decodifica-bollettino-secondaria/) — bollettino realistico del Centro Funzionale Lazio per Genzano: domande di analisi (codici colore, criticità, COC). Soluzioni per il docente.
- 👉 [**Mappa dei rischi del quartiere**](/formazione/schede-stampabili/mappa-rischi-secondaria/) — indagine territoriale: lo studente consulta INGV, ISPRA, DPC, EFFIS e disegna la mappa dei rischi del proprio quartiere. domande di analisi.
- 👉 [**Audit del Piano di Emergenza Scolastico**](/formazione/schede-stampabili/audit-piano-secondaria/) — compito di realtà: la classe analizza il piano di emergenza della scuola in 4 fasi (documenti, sopralluogo, intervista, sintesi). Output: report al Dirigente.
- 👉 [**Blackout e servizi essenziali**](/formazione/schede-stampabili/blackout-servizi-essenziali-secondaria/) — disagio, urgenza ed emergenza: piano familiare in caso di interruzione di luce, telefono o acqua. box "Prima/Durante/Comunicazioni/Quando chiamare", attività domestiche, mini quiz. *(ed. civica, tecnologia)*
- 👉 [**Rischio chimico-industriale**](/formazione/schede-stampabili/rischio-industriale-secondaria/) — perché davanti a una nube o un odore chimico anomalo la regola è "al contrario": riparo al chiuso invece di fuga. Normativa Seveso, pannelli arancioni, attività di confronto tra regole e mini quiz. *(scienze, ed. civica)*
- 👉 [**Rischio nucleare e radiologico**](/formazione/schede-stampabili/rischio-nucleare-radiologico-secondaria/) — perché il rischio radiologico riguarda l'Italia anche senza centrali attive: i tre principi della radioprotezione, il riparo al chiuso, la iodoprofilassi solo su indicazione ufficiale. Attività di confronto e mini quiz. *(scienze, ed. civica)*
- 👉 [**Leggere il bollettino ondate di calore**](/formazione/schede-stampabili/ondate-calore-secondaria/) — il bollettino del Ministero della Salute: livelli 0-1-2-3, come si legge, comportamenti per sé e per le persone fragili, con esercizio su un bollettino di esempio. *(scienze, ed. civica)*
- 👉 [**Monossido di carbonio**](/formazione/schede-stampabili/monossido-carbonio-secondaria/) — il pericolo invisibile in case, garage e locali chiusi: prevenzione, usi vietati di barbecue/bracieri, segnali sospetti e azione sicura. Caccia al rischio in casa e mini quiz. *(scienze, tecnologia)*
- 👉 [**Maremoto: la fisica e i comportamenti**](/formazione/schede-stampabili/maremoto-comportamenti-secondaria/) — come si genera un maremoto (velocità dell'onda in mare aperto e in costa), il Sistema di Allertamento SiAM, i tre segnali naturali e i comportamenti di autoprotezione. Mini verifica e soluzioni. *(scienze, geografia, ed. civica)*
- 👉 [**IT-alert e comunicazioni ufficiali**](/formazione/schede-stampabili/it-alert-comunicazioni-secondaria/) — capire il sistema nazionale di allarme pubblico: anatomia di un messaggio (rischio/area/tempo/azione/fonte), esempio realistico, risposta in 140 caratteri, mini quiz. *(ed. civica, cittadinanza digitale, italiano)*
- 👉 [**Notizie false in emergenza**](/formazione/schede-stampabili/fake-news-emergenza-secondaria/) — riconoscere e fermare la disinformazione: regola dei 3 controlli (fonte/data/conferma), checklist "prima di condividere", classifica delle notizie a gruppi e mini quiz. *(ed. civica digitale, italiano)*

**Schede curriculari trasversali** (matematica, italiano, ed. civica, scienze):

- 👉 [**Statistica dei Rischi Italiani**](/formazione/schede-stampabili/statistica-rischi-secondaria/) — tabella DPC, calcolo percentuali, costruzione istogramma, riflessione sui dati. *(matematica)*
- 👉 [**Scrivi un Testo Informativo**](/formazione/schede-stampabili/scrittura-informativa-secondaria/) — produrre un testo di ~300 parole su un rischio del territorio (struttura 5W + fonti). *(italiano)*
- 👉 [**Debate strutturato sui Rischi**](/formazione/schede-stampabili/debate-strutturato-secondaria/) — debate scolastico in 5 fasi su un tema PC (vietare costruzioni in zona sismica). Griglia di valutazione. *(ed. civica)*
- 👉 [**Costituzione e PC — Analisi**](/formazione/schede-stampabili/costituzione-pc-secondaria/) — articoli 32, 117, 118 con testo originale + glossario costituzionale + domande di approfondimento. *(ed. civica)*
- 👉 [**Vulcanologia dei Castelli Romani**](/formazione/schede-stampabili/vulcanologia-castelli-secondaria/) — il Vulcano Laziale: caldera, fumarole, monitoraggio INGV. Schema della caldera con i due laghi. *(scienze)*
- 👉 [**La siccità ai Castelli Romani — leggere i dati**](/formazione/schede-stampabili/siccita-castelli-secondaria/) — i dati climatici reali di Genzano (pioggia annua e giorni molto caldi, rianalisi ERA5): media, scarti e lettura delle serie, con aggancio al [Laboratorio meteo](/laboratorio-meteo/) del sito. *(matematica, scienze, geografia)*
- 👉 [**Cronaca Recente — Ischia 2022**](/formazione/schede-stampabili/cronaca-recente-secondaria/) — articolo di cronaca su frana di Casamicciola. Analisi 5W + domande critiche. *(italiano)*
- 👉 [**Articolo, Comunicato Stampa e Post Social**](/formazione/schede-stampabili/articolo-stampa-social-secondaria/) — piramide rovesciata + 5W+1H. Lo stesso evento PC in 3 formati (articolo, comunicato stampa, post Instagram) con esempio modello e hashtag strategici. *(italiano, giornalismo)*

**Schede del curricolo a spirale 6-19 anni — versione Secondaria I** (stessi temi disponibili anche per Primaria e Secondaria II, per scelta del docente):

- 👉 [**Caso Amatrice — cronologia e analisi**](/formazione/schede-stampabili/caso-amatrice-secondaria/) — terremoto Centro Italia 2016 con timeline (24 agosto, 30 ottobre, Rigopiano gennaio 2017) + analisi cosa ha funzionato/non ha funzionato + domande. *(storia, scienze, ed. civica)*
- 👉 [**Piano di Emergenza Familiare — esteso**](/formazione/schede-stampabili/piano-familiare-secondaria/) — versione approfondita del piano: scorte 72 ore, contatto fuori comune, animali domestici, persone fragili, ruoli di tutti. *(ed. civica, da completare con la famiglia)*
- 👉 [**Cruciverba PC — definizioni tecniche**](/formazione/schede-stampabili/cruciverba-secondaria/) — definizioni tecniche (sigle istituzionali, fenomeni, ruoli) collegabile al glossario online del sito. *(italiano, scienze)*
- 👉 [**Calcolo dei tempi di evacuazione**](/formazione/schede-stampabili/labirinto-evacuazione-secondaria/) — pianta scuola di esempio + dati di norma (DM 3/8/2015): calcolo capacità uscite, tempo evacuazione totale, verifica conformità. Problemi matematici. *(matematica, tecnologia)*
- 👉 [**Chiamare il 112 — Cosa NON dire**](/formazione/schede-stampabili/chiamo-112-secondaria/) — scenari realistici (incidente bici, bambino al parco, anziano svenuto) con riformulazione di chiamate inefficaci, sistema AML, art. 658 c.p. *(italiano, ed. civica)*

**Casi studio — le maxi-emergenze italiane con analisi argomentativa (11-13 anni):** schede di analisi storica con cronologia evento, box "Cosa ha funzionato / Cosa NON ha funzionato", domande argomentative e note per il docente con riferimenti normativi (D.Lgs. 1/2018, L. 92/2019, D.M. 183/2024). Stesso evento disponibile in fasce per il curricolo a spirale (Primaria 9-11 → Sec I 11-13 → Sec II 14-19).

- 👉 [**Caso Amatrice 2016**](/formazione/schede-stampabili/caso-amatrice-secondaria/) — cronologia 24 agosto/30 ottobre 2016, IT-alert, evacuazioni preventive, ricostruzione lenta. *(storia/scienze/ed. civica)*
- 👉 [**Caso Friuli 1976**](/formazione/schede-stampabili/caso-friuli-secondaria/) — "dov'era e com'era": modello internazionale di ricostruzione + Legge 225/1992. *(storia/geografia)*
- 👉 [**Caso Irpinia 1980**](/formazione/schede-stampabili/caso-irpinia-secondaria/) — "Fate presto": Pertini in tv, Zamberletti, nascita Servizio Nazionale PC. *(storia/ed. civica)*
- 👉 [**Caso L'Aquila 2009**](/formazione/schede-stampabili/caso-aquila-secondaria/) — sciame sismico, Commissione Grandi Rischi, Case C.A.S.E., riforma comunicazione del rischio. *(storia/scienze)*
- 👉 [**Caso Vajont 1963**](/formazione/schede-stampabili/caso-vajont-secondaria/) — disastro annunciato: ascolto della scienza, responsabilità tecnica e politica, Tina Merlin. *(storia/scienze/ed. civica)*
- 👉 [**Caso Messina-Reggio 1908**](/formazione/schede-stampabili/caso-messina-secondaria/) — tsunami, prima legge antisismica al mondo (R.D.L. 193/1909), cooperazione internazionale. *(storia/scienze)*
- 👉 [**Caso Stava 1985**](/formazione/schede-stampabili/caso-stava-secondaria/) — responsabilità d'impresa, riforma controlli ambientali, Direttiva Seveso II. *(scienze/ed. civica)*
- 👉 [**Caso Sarno 1998**](/formazione/schede-stampabili/caso-sarno-secondaria/) — colata detritica, Legge 267/1998, Piani di Assetto Idrogeologico (PAI). *(scienze/geografia)*
- 👉 [**Caso Versilia 1996**](/formazione/schede-stampabili/caso-versilia-secondaria/) — flash flood, nascita dei Centri Funzionali, codici colore allerta meteo, IT-alert. *(scienze/geografia)*
- 👉 [**Caso Rigopiano 2017**](/formazione/schede-stampabili/caso-rigopiano-secondaria/) — rischio multiplo concomitante: sisma + neve + viabilità chiusa, responsabilità del Sindaco. *(scienze/ed. civica)*
- 👉 [**I vulcani d'Italia**](/formazione/schede-stampabili/caso-vulcani-italia-secondaria/) — Etna, Stromboli, Vesuvio, Campi Flegrei, Vulcano: monitoraggio INGV, piani di evacuazione. *(scienze/geografia)*
- 👉 [**I Campi Flegrei**](/formazione/schede-stampabili/caso-campi-flegrei-secondaria/) — caldera, bradisismo, monitoraggio INGV-OV, piano di evacuazione 500.000 persone. *(scienze/geografia/ed. civica)*
- 👉 [**Caso San Giuliano di Puglia 2002**](/formazione/schede-stampabili/caso-san-giuliano-secondaria/) — il crollo della scuola Jovine e la sicurezza delle scuole: classificazione sismica (OPCM 3274/2003), Giornata nazionale della sicurezza nelle scuole. *(storia/ed. civica)*
- 👉 [**Caso Vermicino 1981**](/formazione/schede-stampabili/caso-vermicino-secondaria/) — la vicenda di Alfredino Rampi e la nascita della Protezione Civile moderna: dal caos dei soccorsi alla L. 225/1992, fino al D.Lgs. 1/2018. *(storia/ed. civica)*

---

## Compito di realtà — Analisi del Piano di Emergenza Scolastico

Un'attività alternativa o complementare all'UdA, più breve (4-6 ore), direttamente ancorata alla scuola.

**Consegna agli studenti**: *"Ogni scuola italiana ha un Piano di Emergenza. Il vostro compito è analizzare il Piano della nostra scuola, verificarne la conoscenza da parte di compagni più piccoli e formulare una proposta di miglioramento."*

**Fasi**
1. Richiesta al Dirigente Scolastico di una copia del Piano (o della sua sintesi)
2. Lettura in gruppo del Piano con evidenziazione dei punti chiave (vie di fuga, punto di raccolta, ruoli)
3. Sondaggio (anonimo, max domande) rivolto a una classe di scuola primaria dello stesso istituto: "Sai dove si trova l'uscita di emergenza? Sai cosa fare se suona l'allarme?"
4. Analisi dei risultati
5. Redazione di un **report di proposta** al Dirigente: cosa funziona, cosa si potrebbe migliorare (es. cartelli più chiari, esercitazioni più frequenti, materiale informativo agli alunni)
6. Presentazione del report in Consiglio di Istituto o in un momento pubblico della scuola

**Valore formativo**
- Conoscenza di un documento istituzionale reale
- Esercizio di cittadinanza attiva all'interno della scuola
- Sviluppo della capacità di comunicare criticamente con gli adulti di riferimento

---

## Approfondimenti cross-disciplinari

Spunti per ampliare il percorso integrandolo con altre discipline.

### Italiano — Letteratura delle catastrofi

- **Dino Buzzati** — "La valanga" (racconto breve): come la letteratura racconta il pericolo atteso
- **Italo Calvino** — lettere giovanili sul dopoguerra italiano: il tema della ricostruzione
- **Articolo di giornale** — confronto tra un articolo "sensazionalistico" e uno "istituzionale" sullo stesso evento (es. alluvione di Genova 2011, sisma Centro Italia 2016): analisi stilistica

### Storia — Eventi-chiave nella storia della Protezione Civile italiana

- **1908 — Terremoto di Messina** (magnitudo 7.1, oltre 80.000 morti) → nascita delle prime norme sul soccorso
- **1966 — Alluvione di Firenze** (4 novembre) → nascita degli "angeli del fango", primo volontariato spontaneo organizzato
- **1976 — Terremoto del Friuli** (magnitudo 6.5, 976 morti) → nasce il modello di ricostruzione partecipata ("com'era, dov'era")
- **1980 — Terremoto dell'Irpinia** (magnitudo 6.9, 2.914 morti) → evidenzia la necessità di un sistema nazionale coordinato
- **1992 — Legge 225** → nasce il Servizio Nazionale di Protezione Civile (con Giuseppe Zamberletti)
- **2009 — Terremoto dell'Aquila** (magnitudo 6.3, 309 morti) → caso G8 e processo alla Commissione Grandi Rischi
- **2012 — Terremoto in Emilia** → prima vera prova del sistema attuale
- **2016-2017 — Sequenza sismica Centro Italia** → Amatrice, Norcia, Accumoli

### Arte e immagine — La segnaletica di sicurezza

Studio della segnaletica: il **Decreto Legislativo 81/2008** stabilisce forme e colori dei cartelli. Divieti (cerchio rosso), pericoli (triangolo giallo), prescrizioni (cerchio blu), salvataggio (rettangolo verde), antincendio (rettangolo rosso). Gli alunni progettano un set di cartelli per una situazione nuova (es. emergenza climatica in spiaggia).

### Tecnologia — Strumenti digitali di monitoraggio

- **IT-alert**: analisi del sistema Cell Broadcast (come funziona tecnicamente)
- **App del DPC**: esplorazione funzioni
- **Portali open data**: ISPRA IdroGEO, INGV webservices, Copernicus EMS
- Confronto tra **dati ufficiali e previsioni commerciali**: perché un'app privata non è un'allerta

### Musica — Le sirene e i suoni dell'emergenza

Storia del suono dell'allerta: la sirena antiaerea della Seconda Guerra Mondiale, il suono del sistema di allerta civile degli anni '80, il suono digitale di IT-alert. Perché certi suoni "sbloccano" istintivamente l'allerta nel nostro cervello? (Frequenze, onda modulata, effetto Doppler).

---

## Rubrica di valutazione delle competenze

| Competenza | Iniziale (D) | Base (C) | Intermedio (B) | Avanzato (A) |
|---|---|---|---|---|
| **Comprensione del sistema istituzionale** | Non riconosce la struttura del sistema | Elenca le componenti principali | Descrive ruoli e competenze con esempi | Analizza criticamente il principio di sussidiarietà con casi concreti |
| **Conoscenza dei rischi** | Conoscenza frammentaria | Riconosce i rischi principali | Collega rischi, cause e territorio | Formula ipotesi su scenari futuri (cambiamento climatico) |
| **Lettura delle fonti** | Usa fonti non ufficiali | Riconosce le fonti ufficiali se indicate | Consulta autonomamente fonti ufficiali e ne valuta l'attendibilità | Confronta più fonti e distingue notizie false |
| **Comportamento in emergenza** | Non esegue correttamente le procedure | Esegue le procedure se guidato | Esegue correttamente in autonomia | Aiuta i compagni e riconosce errori nelle procedure osservate |
| **Pianificazione** | Non produce il piano familiare | Produce un piano essenziale | Produce un piano completo e coerente | Produce un piano completo, lo discute con la famiglia, lo aggiorna |
| **Comunicazione del rischio** | Produce messaggi allarmistici o imprecisi | Produce messaggi corretti ma poco efficaci | Produce messaggi corretti, chiari, adatti al target | Produce messaggi efficaci e sa progettare una campagna |
| **Cittadinanza attiva** | Partecipa in modo passivo | Esegue ciò che viene richiesto | Partecipa attivamente con proposte | Promuove iniziative nella classe o nella scuola |

**Conversione in voto decimale** (orientativa per Educazione Civica):
- D → 5   ·   C → 6-7   ·   B → 8   ·   A → 9-10

**Certificazione delle competenze di fine primo ciclo**: il percorso produce evidenze per le competenze 4 (personale, sociale, imparare a imparare), 5 (cittadinanza), 6 (imprenditoriale) e 7 (consapevolezza culturale) della Raccomandazione UE 2018.

---

## Adattamenti per l'inclusione

### Alunni con DSA

- **Dislessia**: fornisci sintesi ad alta leggibilità (font EasyReading/OpenDyslexic, spaziatura 1,5); permetti l'uso di strumenti compensativi (sintesi vocale, registrazione della lezione)
- **Discalculia**: per scale numeriche (magnitudo, millimetri di pioggia) fornisci sempre la rappresentazione visiva (infografiche proporzionali)
- **Disgrafia**: accetta produzione digitale (testo al computer), presentazioni orali, schemi visivi
- Per il **Compito di realtà**, valorizza il contributo specifico dell'alunno (ricerca, grafica, presentazione orale) rispetto al prodotto scritto

### Alunni con disabilità intellettiva

- Coordinati con il docente di sostegno: il PEI definisce obiettivi personalizzati
- Privilegia i moduli 1, 4 e 5 (più concreti e operativi)
- Usa gioco di ruolo e simulazioni per fissare i concetti
- Per il Piano familiare, semplifica la scheda a 3-4 voci essenziali

### Alunni con disturbo dello spettro autistico

- Fornisci sempre una scaletta dell'incontro (cosa faremo, in che ordine, per quanto tempo)
- Evita cambi di programma improvvisi durante le esercitazioni
- Per i lavori di gruppo, assegna un ruolo preciso e delimitato (es. ricerca fonti, scrittura di una sezione specifica, revisione grafica)

### Alunni con disabilità motoria

- Per le esercitazioni segui il **PEI** e il Piano di Emergenza della scuola (buddy, percorsi accessibili)
- Rendi l'alunno protagonista del Compito di realtà nella parte di analisi e redazione

### Alunni stranieri con italiano L2

- Fornisci glossari bilingue con i termini chiave (allerta, evacuazione, magnitudo, sismico, idrogeologico)
- Per la lettura del bollettino, usa prima la versione semplificata del DPC
- Sfrutta i compagni italofoni in gruppi cooperativi

### Alunni plusdotati

- Proponi approfondimenti sul **Codice della Protezione Civile** (D.Lgs. 1/2018 integrale)
- Incarica di guidare il gruppo nel Compito di realtà con ruolo di "project manager"
- Offri lo spunto del **dibattito sull'art. 118 della Costituzione** (sussidiarietà orizzontale)

---

## Raccordo con il Piano di Emergenza della Scuola

Ogni istituto scolastico possiede un Piano di Emergenza e di Evacuazione ai sensi del **D.M. 26/08/1992** e del **D.Lgs. 81/2008**. Il kit didattico si integra con il Piano d'istituto su questi punti:

- **Modulo 4 (Autoprotezione)** → coordinamento con l'RSPP della scuola per la verifica delle procedure d'istituto
- **Compito di realtà (Analisi del Piano)** → richiede l'accesso al Piano d'istituto tramite il Dirigente
- **Esercitazioni di evacuazione** → integrare il Modulo con le prove ufficiali previste dalla normativa
- **Alunni con fragilità** → le procedure del Piano (accompagnatori, percorsi preferenziali) sono prioritarie rispetto alle attività del kit

**Consiglio**: prima di avviare il percorso, richiedi un incontro con RSPP e Dirigente. È un'occasione per aggiornare congiuntamente le procedure della scuola e per eventualmente aggiornare il Piano stesso.

### Il Piano di Evacuazione come oggetto di studio

Il Piano non va visto solo come vincolo ma come **testo istituzionale vivente** da studiare in classe:
- Chi lo ha redatto (RSPP, Dirigente, tecnici)
- Quando è stato aggiornato
- Quali rischi considera
- Come si raccorda con il Piano di Emergenza Comunale di Genzano

Il [Piano di Emergenza Comunale di Genzano](/piano-emergenza/) è pubblicato sul sito del Gruppo: gli studenti possono confrontare il Piano scolastico con quello comunale per verificare la coerenza.

---

## Coinvolgimento delle famiglie

### Patto formativo iniziale

All'avvio dell'UdA o del Modulo 5, coinvolgi i genitori con una comunicazione che spiega:
- Gli obiettivi dell'UdA e il collegamento con l'Educazione Civica
- La richiesta di partecipare alla redazione del Piano familiare
- L'opportunità di un incontro informativo con i volontari del Gruppo

### Assemblea di classe con il Gruppo

Una volta l'anno, organizza un'**assemblea di classe aperta ai genitori** (45 minuti) in cui gli studenti presentano il Piano familiare e un volontario del Gruppo illustra il contesto territoriale e le risorse disponibili. È un momento di cittadinanza che coinvolge tre generazioni (studenti, genitori, volontari).

### Uscita congiunta

Per le classi terze, valuta un'uscita didattica alla **sede del Gruppo** con la partecipazione opzionale di un genitore per classe: è un'occasione concreta per conoscere il volontariato locale.

---

## FAQ del docente

**D. Come integro il percorso nelle 33 ore di Educazione Civica?**
R. Puoi dedicare 10-12 ore a questo percorso in terza media, concentrandole nel II quadrimestre. Le restanti ore si distribuiscono su altri nuclei tematici (cittadinanza digitale, Agenda 2030, diritti umani). L'UdA interdisciplinare è una buona cornice perché permette di contare le ore di più discipline.

**D. I miei studenti banalizzano ("tanto a noi non succede niente")**
R. Usa dati locali. Quando scopri che Genzano è in **zona sismica 2B**, che a Nemi ci sono stati fenomeni di frana documentati, che nel 2014 una grandinata ha causato danni significativi sui Castelli, cambia la percezione. Il DPC ha statistiche dettagliate per ogni comune ([mappe.protezionecivile.gov.it](https://mappe.protezionecivile.gov.it/)).

**D. Gli studenti seguono fonti di disinformazione online (TikTok, Instagram)**
R. È un'opportunità, non un ostacolo. Il **Modulo 5 (Comunicazione del rischio)** nel kit secondaria di secondo grado approfondisce proprio questo. Porta in classe esempi concreti: un post falso che circola su un "terremoto previsto per domani" è una lezione di cittadinanza digitale.

**D. Come gestisco le opinioni divergenti sulla scienza del clima o sul rischio?**
R. Distingui **fatti scientifici** (dati dell'IPCC, dell'INGV, dell'ISPRA) da **opinioni politiche** sul come gestirli. I fatti non si negoziano, le scelte politiche sì. Questa distinzione è di per sé un obiettivo di cittadinanza.

**D. Posso valutare con voto numerico?**
R. Sì, l'Educazione Civica prevede voto in decimi. La rubrica qui proposta si converte facilmente (D=5, C=6-7, B=8, A=9-10). Il voto finale è proposto dal docente coordinatore di Educazione Civica sulla base delle evidenze raccolte.

**D. Il volontario può portare attrezzature a scuola (radio, casco, divisa)?**
R. Sì, previa autorizzazione del Dirigente. Vengono portate attrezzature in uso ordinario: radio VHF/UHF, casco da AIB, DPI, un piccolo kit di primo soccorso. Per armi o mezzi grandi servono autorizzazioni più complesse non sempre compatibili con la scuola.

**D. Si può fare un PCTO (alternanza) con la Protezione Civile?**
R. Sì, ma solo per la **scuola secondaria di secondo grado**. Il kit della secondaria di primo grado prevede al massimo una visita didattica o un'attività di service learning all'interno della scuola.

**D. Come gestisco un alunno che ha subito un evento traumatico (terremoto, alluvione, perdita familiare)?**
R. Coordinati con il docente referente BES/DSA, lo psicologo scolastico (se presente), la famiglia. In generale: non forzare la partecipazione a simulazioni, valorizza l'esperienza dell'alunno come risorsa (se lui vuole condividerla), mantieni un tono calmo e concreto.

**D. Il Piano di Emergenza scolastico è riservato? Posso farlo vedere agli studenti?**
R. Il Piano d'istituto **non è un documento segreto**: va comunicato alla popolazione scolastica. Le parti sensibili (dati personali di alunni con fragilità) vanno tutelate, ma la parte generale è pensata per essere conosciuta. Concordalo con il Dirigente e l'RSPP.

---

## Altri casi studio e attività di approfondimento

Materiale integrativo per il docente che vuole offrire esempi **concreti, recenti e italiani** alla classe. Tutti i casi qui elencati sono eventi realmente accaduti, con fonti istituzionali verificabili. Per ogni caso studio sono indicati obiettivo didattico, materiali, domande-guida, durata.

### Caso studio 1 — Amatrice 24 agosto 2016 (terremoto)

**Obiettivo**: capire come si attiva il Sistema Nazionale di Protezione Civile in un evento di magnitudo 6.0, il ruolo di INGV, dei volontari, del Dipartimento.

**Materiali**: rassegna stampa dei primi 5 giorni, report INGV (sito istituzionale), video del DPC sull'attivazione della colonna mobile.

**Svolgimento (2 ore)**:
1. Introduzione del docente: contesto sismico del Centro Italia, faglie attive. (15 min)
2. Visione di un video DPC di 10 minuti. (15 min)
3. Lavoro in gruppi: ogni gruppo analizza un aspetto — (A) soccorso sanitario, (B) ricerca dispersi, (C) allestimento tendopoli, (D) gestione sfollati, (E) ruolo dei volontari. (45 min)
4. Restituzione in plenaria e discussione. (30 min)
5. Compito a casa: scrivere un breve articolo di giornale (300-400 parole) dal punto di vista di un giornalista dell'epoca. (autonomo)

**Domande-guida per la discussione**:
- Perché alcuni edifici sono crollati e altri sono rimasti in piedi?
- Qual è la differenza tra "soccorso sanitario" (ARES 118) e "soccorso tecnico" (VVF)?
- Chi decide quando si può tornare a dormire in casa dopo una scossa?
- Quale è stato il ruolo del volontariato di protezione civile? Dei volontari esperti vs spontanei?

### Caso studio 2 — Alluvione Emilia-Romagna maggio 2023

**Obiettivo**: comprendere la gestione di un evento alluvionale di grande scala e il nesso con il cambiamento climatico.

**Materiali**: report ARPAE Emilia-Romagna, mappe di Copernicus EMS (attivazione EMSR661), articoli scientifici su medicane e eventi compound.

**Domande-guida**:
- Cos'è un "evento compound"? (siccità → suolo impermeabile → alluvione rapida)
- Perché 23 fiumi hanno rotto gli argini in 36 ore?
- Qual è stato il ruolo di [IT-alert](https://www.it-alert.it/) nella prima sperimentazione?
- I volontari da Lazio sono stati inviati? Come si organizza la colonna mobile regionale?

### Caso studio 3 — Frana di Ischia 26 novembre 2022

**Obiettivo**: analizzare il rapporto tra abusivismo edilizio, dissesto idrogeologico e rischio.

**Materiali**: report ISPRA, articoli giornalistici verificati, mappe PAI.

**Domande-guida**:
- Perché su Ischia ci sono così tanti edifici in aree classificate a rischio?
- Cosa significa "condono edilizio" e quale effetto ha sul rischio?
- Una comunità può tornare a vivere sicura dopo un evento simile? Cosa cambia?

### Caso studio 4 — Incendi estivi Sardegna luglio 2021

**Obiettivo**: capire la prevenzione AIB, il ruolo dei Canadair, la pianificazione regionale.

**Materiali**: dati EFFIS, report Corpo Forestale, piano AIB Sardegna.

**Domande-guida**:
- Perché il 99% degli incendi boschivi in Italia ha origine dolosa o colposa?
- Cosa fa un volontario AIB? (non spegne direttamente le fiamme: fa avvistamento, contenimento, supporto logistico)
- Come si integrano la componente aerea (Canadair, elicotteri) e terrestre?

### Caso studio 5 — Terremoto dei Campi Flegrei (bradisismo in corso)

**Obiettivo**: collegare l'attualità alla vulcanologia, comprendere il **rischio vulcanico quiescente** (rilevante per i Colli Albani, il nostro territorio).

**Materiali**: rapporti INGV-OV (Osservatorio Vesuviano), piano di emergenza Campi Flegrei del DPC, playlist video ufficiale [Bradisismo Campi Flegrei 2024](https://www.youtube.com/playlist?list=PLaLgDI0rVT4AhRiJWDMRACf9kynNGmxnh) del Dipartimento della Protezione Civile.

**Domande-guida**:
- Cosa significa "bradisismo"?
- Perché i Campi Flegrei sono considerati tra i vulcani più pericolosi del mondo?
- Esiste un piano simile per i Colli Albani? Cosa dice?
- Come comunica l'INGV ai cittadini le sue osservazioni scientifiche?

### Attività: simulazione di comunicazione di crisi

**Scenario**: un temporale intenso sta per colpire Genzano. La Regione Lazio ha emesso allerta arancione. Il Sindaco attiva il COC. Tu sei il responsabile comunicazione del Comune.

**Compito**: redigere in 30 minuti:
- Un post per Facebook/Instagram (max 80 parole, tono calmo ma chiaro)
- Un messaggio Telegram di aggiornamento alla popolazione (max 150 parole)
- Una nota stampa per le testate locali (max 300 parole)

**Valutazione**: chiarezza, correttezza delle informazioni, rispetto dei registri comunicativi diversi, assenza di allarmismo.

**Debriefing in classe (20 minuti)**:
- Confronto tra i diversi testi prodotti
- Analisi: quali errori sono stati commessi più spesso? (terrorismo psicologico, uso di tecnicismi, informazioni non verificate)
- Lettura di comunicazioni ufficiali reali (DPC, Regione Lazio) per confronto.

### Service learning — 4 proposte operative

Attività in cui gli studenti **agiscono concretamente** per la comunità, coniugando apprendimento e cittadinanza attiva.

**Progetto 1 — "Io non rischio Junior"**: gli studenti, formati da un volontario, preparano un banchetto informativo (con brochure, poster, gadget) da allestire in una piazza di Genzano il sabato mattina. Durata: 1 mattinata + 3 incontri preparatori.

**Progetto 2 — Adotta un'area di attesa**: una classe si assume la responsabilità di monitorare nel corso dell'anno lo stato dei cartelli e la segnaletica di una delle aree di attesa del Comune. Segnala al Gruppo eventuali danni o mancanze. Durata: tutto l'anno scolastico.

**Progetto 3 — Nonni sicuri**: gli studenti preparano e conducono un incontro di 90 minuti presso un centro anziani per spiegare il 112, l'IT-alert, le allerte meteo. Include una dispensa cartacea stampata. Durata: 1 incontro + 4 incontri preparatori.

**Progetto 4 — Podcast "Sicuri insieme"**: produzione di una serie di 4-6 podcast di 10 minuti ciascuno sui rischi del territorio, intervistando esperti locali (volontari, geologi, docenti universitari). Pubblicazione su piattaforme aperte (Spreaker free, YouTube). Durata: 2 mesi. Valutabile per competenze digitali + italiano.

### Intervista al volontario — traccia strutturata

Prima che il volontario venga in classe, gli studenti preparano domande in piccoli gruppi. Traccia di **Domande di qualità** (non banali) da personalizzare:

**Personali**
1. Quando hai deciso di diventare volontario di protezione civile? Cosa ti ha spinto?
2. Quanto tempo dedichi al volontariato in una settimana-tipo?
3. Ricordi la prima attivazione in cui sei stato coinvolto? Com'è andata?

**Tecniche**
4. Che tipo di formazione serve per diventare operativo?
5. Cosa c'è nel tuo zaino operativo? Perché proprio quelle cose?
6. In che consiste una "colonna mobile"?

**Sul nostro territorio**
7. Qual è il rischio principale per Genzano secondo te?
8. Quante volte all'anno si attiva il Gruppo per un'emergenza vera?
9. Cosa può fare un cittadino comune per aiutare il Gruppo?

**Etiche / di cittadinanza**
10. Cosa pensi dell'autoprotezione come dovere civico?
11. È capitato di intervenire in un'emergenza che avrebbe potuto essere evitata? Cosa ne pensi?
12. C'è stato un momento in cui hai avuto paura? Come l'hai gestito?

**Su futuro / tecnologia**
13. Come sta cambiando il volontariato con le nuove tecnologie (droni, IT-alert, social)?
14. Pensi che il cambiamento climatico cambierà il vostro lavoro?
15. Cosa consiglieresti a un ragazzo della nostra età che vuole impegnarsi per la comunità?

### Discussione etica guidata — 4 dilemmi

In plenaria, per 20-30 minuti. Il docente pone il dilemma, la classe discute con la regola del **microfono** (parla solo chi ha la parola). Nessuna risposta "giusta" predefinita — l'obiettivo è far ragionare.

**Dilemma 1**: "Durante un terremoto sei a scuola. Il tuo compagno resta paralizzato sotto il banco e non si alza. Tu hai 12 anni. Lo prendi di forza per portarlo fuori, resti con lui dentro, corri a cercare la maestra? Cosa scegli?"

**Dilemma 2**: "Hai una diretta Instagram mentre c'è un'emergenza in corso nel tuo quartiere. È giusto trasmettere? Aiuta o danneggia la gestione?"

**Dilemma 3**: "Abiti in un'area a rischio frana. Il Comune ha deciso di evacuare il tuo palazzo. Tu non vuoi andare: è casa tua, la ami. Cosa fai? Ha ragione il Comune a obbligarti?"

**Dilemma 4**: "Durante un'alluvione vedi che un negozio ha la saracinesca rotta e c'è merce esposta. Un passante sta prendendo qualcosa. Cosa fai?"

Alla fine si chiede agli studenti di scrivere in 10 righe la propria posizione e giustificarla.

---

## Materiale consigliato

- [Piano di Emergenza Familiare](/piano-familiare/) — Modello stampabile e compilabile
- [Aree di emergenza di Genzano](/cartografia/) — Mappa delle aree di attesa e accoglienza
- [Piano di Emergenza Comunale](/piano-emergenza/) — Struttura del piano del Comune
- [Quiz di Protezione Civile](/quizpc/) — Quiz interattivo
- [Giochi della Sicurezza — Ragazzi](/giochi/ragazzi/) — giochi per la fascia 11-14
- [Stop Disasters! — Simulatore ONU UNDRR](https://www.stopdisastersgame.org/game/) — Simulazione gratuita in italiano: 5 scenari (terremoto, alluvione, tsunami, uragano, incendio) per imparare la pianificazione e la prevenzione. Adatto a 11-14 anni come attività di gruppo guidata in classe (durata 10-20 minuti per scenario).
- [Io non rischio](https://www.iononrischio.it/) — Materiali della campagna nazionale
- [La Protezione Civile nella scuola](https://www.protezionecivilegenzano.it/documenti/download/PC_scuola.pdf) — Manuale DPC e Ministero dell'Istruzione
- [IdroGEO](https://idrogeo.isprambiente.it/) — Mappa frane e alluvioni di ISPRA
- [INGV Terremoti](https://terremoti.ingv.it/) — Dati sismici in tempo reale

### Fonti normative e curricolari

- [Legge 20 agosto 2019 n. 92](https://www.normattiva.it/) — Introduzione dell'insegnamento dell'educazione civica (art. 3 lett. h *protezione civile*; lett. h-ter *sicurezza nei luoghi di lavoro* introdotta dalla L. 21/2025)
- **D.M. 7 settembre 2024 n. 183 (Linee Guida nazionali per l'Educazione Civica, applicabili a decorrere dall'anno scolastico 2024/2025)** — Linee guida per l'insegnamento dell'educazione civica
- **Legge 17 febbraio 2025, n. 21** — Conoscenze di base in materia di sicurezza nei luoghi di lavoro nell'Educazione Civica
- **Indicazioni Nazionali per il Curricolo** (2012) + **Nuovi Scenari** (2018) — Scuola Secondaria di Primo Grado
- **Raccomandazione UE 2018/C 189/01** — Competenze chiave per l'apprendimento permanente
- [D.Lgs. 2 gennaio 2018 n. 1](/normativa/testo-unico-protezione-civile/) — Codice della Protezione Civile (cornice generale del Servizio nazionale)
- **D.M. 742/2017** — Certificazione delle competenze di fine primo ciclo
- **D.Lgs. 81/2008** — Sicurezza nei luoghi di lavoro
- **D.M. 26/08/1992** — Norme prevenzione incendi scuole

---

## Vuoi organizzare un incontro?

I volontari del Gruppo sono disponibili per interventi nelle scuole con presentazioni, dimostrazioni pratiche e simulazioni. Possiamo anche organizzare una visita alla sede operativa.

Scrivi a [segreteria@protezionecivilegenzano.it](mailto:segreteria@protezionecivilegenzano.it) per concordare il programma.
