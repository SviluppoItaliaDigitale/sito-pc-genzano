KIT DIDATTICO PROTEZIONE CIVILE
Kit Didattico — Scuola Secondaria di Primo Grado
Pacchetto offline · 35 schede · secondaria-primo-grado

================================================================
COME SI USA
================================================================

1. Estrai questo ZIP in una cartella sul tuo computer.

2. Apri il file INDICE.html con doppio click (si apre nel browser).

3. Da lì hai accesso a tutte le schede. Per stampare una scheda:
   apri la scheda, premi Ctrl+P (Windows) o Cmd+P (Mac).

Le schede sono pensate per la stampa A4. Il CSS dedicato nasconde
la barra di navigazione e mostra solo il contenuto stampabile.


================================================================
MODIFICARE UNA SCHEDA
================================================================

Le schede sono file HTML semplici. Per personalizzarle (logo della
scuola, nome insegnante, modifica di un campo) aprile con un editor
di testo (Blocco Note su Windows, TextEdit su Mac, VS Code, ecc.)
e modifica il contenuto. Salva e ristampa.


================================================================
LICENZA
================================================================

I materiali del Gruppo Comunale Volontari di Protezione Civile di
Genzano di Roma sono distribuiti gratuitamente per uso scolastico
e didattico. Citazione del Gruppo gradita ma non obbligatoria.

Per le schede che includono pittogrammi ARASAAC: licenza
CC BY-NC-SA 4.0, attribuzione obbligatoria. Vedi:
https://www.protezionecivilegenzano.it/attribuzioni-pittogrammi/


================================================================
AGGIORNAMENTI
================================================================

Questo pacchetto è generato automaticamente: ogni volta che
aggiungiamo, modifichiamo o togliamo una scheda dal kit, una
nuova versione del pacchetto è disponibile su:

https://www.protezionecivilegenzano.it/formazione/schede-stampabili/

Per restare aggiornato, ri-scarica il pacchetto periodicamente.


================================================================
CONTATTI
================================================================

Gruppo Comunale Volontari di Protezione Civile
Via Sicilia 13-15, Genzano di Roma
segreteria@protezionecivilegenzano.it
https://www.protezionecivilegenzano.it/
